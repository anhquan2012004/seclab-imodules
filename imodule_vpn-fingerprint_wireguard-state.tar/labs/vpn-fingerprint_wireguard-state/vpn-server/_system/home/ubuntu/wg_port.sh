#!/bin/bash
sudo wg set wg0 listen-port "$1" && echo "LISTEN_PORT=$1"
