#!/usr/bin/env python3
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcapio import packets
if len(sys.argv) < 2: sys.exit('usage: hs_stats.py PCAP')
P = [p for p in packets(sys.argv[1]) if p['proto'] == 'udp' and len(p['pay']) >= 4 and p['pay'][1:4] == b'\0\0\0']
ini = [p for p in P if p['pay'][0] == 1 and len(p['pay']) == 148 and p['src'].startswith('10.0.1.')]
rtt, miss = [], 0
for a in ini:
    r = [q for q in P if q['pay'][0] == 2 and len(q['pay']) == 92 and q['dport'] == a['sport'] and q['sport'] == a['dport'] and 0 <= q['ts'] - a['ts'] <= 2.0]
    if r: rtt.append((r[0]['ts'] - a['ts']) * 1000)
    else: miss += 1
n = len(rtt)
if not n: sys.exit('Khong co cap Initiation/Response nao (bat goi truoc khi bat tay chua?)')
m = sum(rtt) / n; sd = (sum((x - m) ** 2 for x in rtt) / n) ** 0.5; s = sorted(rtt)
out = ['INITIATION=%d  co_phan_hoi=%d  khong_phan_hoi=%d  ty_le_phat_hien=%.0f%%' % (len(ini), n, miss, 100 * n / len(ini)),
       'RTT_bat_tay_ms: nho_nhat=%.2f trung_binh=%.2f trung_vi=%.2f lon_nhat=%.2f do_lech_chuan=%.2f' % (s[0], m, s[n // 2], s[-1], sd)]
out.append('HANDSHAKE_STATS_OK n=%d' % n)
open(os.path.expanduser('~/hs_stats.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
