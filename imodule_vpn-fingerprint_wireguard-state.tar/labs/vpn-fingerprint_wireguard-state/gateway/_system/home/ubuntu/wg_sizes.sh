#!/bin/bash
[ -f "$1" ] || { echo "usage: wg_sizes.sh PCAP"; exit 1; }
tshark -r "$1" -T fields -e udp.length 2>/dev/null | awk 'NF{s=$1-8; c[s]++} END{for(s in c){t="DATA"; if(s==148)t="INITIATION"; else if(s==92)t="RESPONSE"; else if(s==32)t="KEEPALIVE"; printf "%s_payload=%d count=%d\n",t,s,c[s]}}' | sort | tee ~/wg_packet_sizes.txt
