#!/usr/bin/env python3
from scapy.all import Ether, IP, TCP, UDP, Raw, wrpcap
import os, struct
os.makedirs('/home/ubuntu/pcaps', exist_ok=True)
def mk_udp(src, dst, sport, dport, payload, t=0.0):
  p = Ether(src='02:42:0a:00:01:65', dst='02:42:0a:00:01:01')/IP(src=src, dst=dst)/UDP(sport=sport, dport=dport)/Raw(load=payload)
  p.time = 1700000000.0 + t
  return p
pkts_http = [Ether()/IP(src='10.0.1.101',dst='10.0.2.20')/TCP(sport=44111,dport=80)/Raw(load=b'GET / HTTP/1.1\r\nHost: intranet.ptit.local\r\n\r\n')]
wrpcap('/home/ubuntu/pcaps/1_http_clean.pcap', pkts_http)
r1 = b'\xaa\xbb\xcc\x01'; r2 = b'\xdd\xee\xff\x02'
wg_clean = [
  mk_udp('10.0.1.101','10.0.2.10',54001,51820, b'\x01\x00\x00\x00'+r1+b'\x11'*140, 0.0),
  mk_udp('10.0.2.10','10.0.1.101',51820,54001, b'\x02\x00\x00\x00'+r1+r1+b'\x22'*80, 0.1),
]
for i in range(1, 5):
  wg_clean.append(mk_udp('10.0.1.101','10.0.2.10',54001,51820, b'\x04\x00\x00\x00'+r1+struct.pack('<Q',i)+b'\x33'*16, i*10.0))
  wg_clean.append(mk_udp('10.0.1.101','10.0.2.10',54001,51820, b'\x04\x00\x00\x00'+r1+struct.pack('<Q',i+10)+b'\x44'*64, i*10.0+0.5))
wg_clean.append(mk_udp('10.0.1.101','10.0.2.10',54001,51820, b'\x01\x00\x00\x00'+r1+b'\x11'*140, 120.0))
wrpcap('/home/ubuntu/pcaps/2_wg_clean.pcap', wg_clean)
decoy = [mk_udp('10.0.1.150','10.0.2.10',59999,51899, b'\x01\x00\x00\x00'+b'\x99'*144, 0.05) for _ in range(4)]
wrpcap('/home/ubuntu/pcaps/3_wg_with_decoy.pcap', decoy + wg_clean)
wg_pad = [
  mk_udp('10.0.1.101','10.0.2.10',54002,51820, b'\x01\x00\x00\x00'+r1+b'\x11'*140+b'\xee'*25, 0.0),
  mk_udp('10.0.2.10','10.0.1.101',51820,54002, b'\x02\x00\x00\x00'+r1+r1+b'\x22'*80+b'\xee'*19, 0.12),
  mk_udp('10.0.1.101','10.0.2.10',54002,51820, b'\x04\x00\x00\x00'+r1+struct.pack('<Q',1)+b'\x44'*64+b'\xee'*13, 0.5)
]
wrpcap('/home/ubuntu/pcaps/4_wg_tail_padded.pcap', wg_pad)
wg_pref = [mk_udp('10.0.1.101','10.0.2.10',54003,51820, b'PTITOBF!\x04\x00\x00\x00'+r1+os.urandom(120), i*0.2) for i in range(10)]
wrpcap('/home/ubuntu/pcaps/5_wg_prefix_obf.pcap', wg_pref)
mp = wg_clean[:3] + [
  mk_udp('10.0.1.102','10.0.2.10',55002,51820, b'\x01\x00\x00\x00'+r2+b'\x11'*140, 1.0),
  mk_udp('10.0.2.10','10.0.1.102',51820,55002, b'\x02\x00\x00\x00'+r2+r2+b'\x22'*80, 1.1),
  mk_udp('10.0.1.102','10.0.2.10',55002,51820, b'\x04\x00\x00\x00'+r2+struct.pack('<Q',1)+b'\x55'*64, 1.5),
  mk_udp('10.0.1.222','10.0.2.10',55002,51820, b'\x04\x00\x00\x00'+r2+struct.pack('<Q',2)+b'\x55'*64, 5.0)
]
wrpcap('/home/ubuntu/pcaps/multi_peer.pcap', mp)
wrpcap('/home/ubuntu/pcaps/6_wg_roaming.pcap', mp[-2:])
print('ALL_PCAPS_READY')
