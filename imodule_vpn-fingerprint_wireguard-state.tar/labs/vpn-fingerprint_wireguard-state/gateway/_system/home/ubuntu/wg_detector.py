#!/usr/bin/env python3
import sys, json, os, time, collections
from scapy.all import rdpcap, sniff, UDP, Raw, IP
if len(sys.argv) < 2: sys.exit("usage: wg_detector.py PCAP | --live SECONDS")
if sys.argv[1] == '--live':
    src = 'live:eth0'; pkts = sniff(iface='eth0', filter='udp', timeout=int(sys.argv[2]))
else:
    src = sys.argv[1]; pkts = rdpcap(src)
state = 'IDLE'; trans = []; inits = []; kas = []; who = ''
for p in pkts:
    if not (p.haslayer(IP) and p.haslayer(UDP) and p.haslayer(Raw)): continue
    b = bytes(p[Raw].load); n = len(b); t = float(p.time)
    if n == 148 and b[:4] == b'\x01\x00\x00\x00':
        inits.append(t); state = 'INIT_SENT'; trans.append(state); who = who or p[IP].src
    elif n == 92 and b[:4] == b'\x02\x00\x00\x00' and state == 'INIT_SENT':
        state = 'ESTABLISHED'; trans.append(state)
    elif b[:4] == b'\x04\x00\x00\x00' and state in ('ESTABLISHED', 'DATA'):
        if state == 'ESTABLISHED': state = 'DATA'; trans.append(state)
        if n == 32 and p[IP].src == who: kas.append(t)
iats = [round(y - x) for x, y in zip(kas, kas[1:])]
peak = collections.Counter(iats).most_common(1)[0][0] if iats else 0
rk = [round(y - x) for x, y in zip(inits, inits[1:])]
rekey = rk[0] if rk else 0
status = 'REKEY_DETECTED' if rk and 100 <= rekey <= 140 else 'NO_REKEY_OBSERVED'
rep = {"source": src, "client": who, "handshake_inits": len(inits), "keepalive_32B_count": len(kas), "keepalive_iat_peak_sec": peak, "rekey_interval_sec": rekey, "transitions": trans[:6], "status": status}
open('/home/ubuntu/scapy_state_report.json', 'w').write(json.dumps(rep, indent=2) + '\n')
if status == 'REKEY_DETECTED':
    os.makedirs('/home/ubuntu/logs_detector', exist_ok=True)
    ev = {"time": time.strftime('%Y-%m-%dT%H:%M:%S'), "src": who, "alert": "WireGuard keepalive=%ss rekey=%ss" % (peak, rekey)}
    open('/home/ubuntu/logs_detector/summary.txt', 'a').write(json.dumps(ev) + '\n')
print(json.dumps(rep, indent=2))
