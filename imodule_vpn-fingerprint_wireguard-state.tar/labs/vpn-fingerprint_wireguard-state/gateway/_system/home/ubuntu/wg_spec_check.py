#!/usr/bin/env python3
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcapio import packets
H = os.path.dirname(os.path.abspath(__file__))
src = open(os.path.join(H, 'wg_spec.py')).read()
if re.search(r'=\s*__', src):
    sys.exit('SPEC_INCOMPLETE: dien not cac cho __ trong wg_spec.py')
ns = {}
exec(src, ns)
if len(sys.argv) < 2: sys.exit('usage: wg_spec_check.py PCAP')
derived = {1: sum(ns['INIT'].values()), 2: sum(ns['RESP'].values()), 4: sum(ns['DATA_HEADER'].values()) + ns['AEAD_TAG']}
obs = {1: set(), 2: set(), 4: set()}
for p in packets(sys.argv[1]):
    if p['proto'] == 'udp' and len(p['pay']) >= 32 and p['pay'][1:4] == b'\0\0\0' and p['pay'][0] in obs:
        obs[p['pay'][0]].add(len(p['pay']))
out = []
ok = True
for t, name in ((1, 'INITIATION'), (2, 'RESPONSE'), (4, 'DATA (keepalive la ban ngan nhat)')):
    o = sorted(obs[t])
    if not o:
        ok = False
        out.append('%-34s suy_ra_tu_dac_ta=%dB  do_duoc=(khong co goi nao)  THIEU_MAU' % (name, derived[t]))
        continue
    m = derived[t] == o[0] and (t != 4 or all((x - derived[t]) % 16 == 0 for x in o))
    ok = ok and m
    out.append('%-34s suy_ra_tu_dac_ta=%dB  do_duoc=%s  %s' % (name, derived[t], o[:6], 'KHOP' if m else 'LECH'))
out.append('SPEC_MATCH' if ok else 'SPEC_MISMATCH')
open(os.path.expanduser('~/wg_spec_result.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
