#!/usr/bin/env python3
import os, json, sqlite3, urllib.parse, time, html
from http.server import BaseHTTPRequestHandler, HTTPServer
SESS = '/home/ubuntu/multi_peer_sessions.txt'
FORM = ''.join('<p>Peer %d: Receiver Index <input name="idx%d"> MAC <input name="mac%d"> User <input name="user%d"></p>' % (i, i, i, i) for i in (1, 2))
class H(BaseHTTPRequestHandler):
    def page(self, body):
        self.send_response(200); self.send_header('Content-type', 'text/html; charset=utf-8'); self.end_headers()
        self.wfile.write(('<html><head><title>PTIT Mini-IdM</title></head><body><h1>PTIT Mini-IdM</h1>' + body + '</body></html>').encode())
    def do_GET(self):
        rows = sqlite3.connect('/home/ubuntu/idm.db').execute('SELECT ip, mac, user, dept FROM devices').fetchall()
        tbl = '<table border=1><tr><th>IP</th><th>MAC</th><th>User</th><th>Dept</th></tr>' + ''.join('<tr>' + ''.join('<td>%s</td>' % html.escape(c) for c in r) + '</tr>' for r in rows) + '</table>'
        self.page('<h3>Devices</h3>' + tbl + '<h3>Submit Incident Ticket</h3><form method="POST" action="/submit">' + FORM + '<button type="submit">Submit Ticket</button></form>')
    def do_POST(self):
        q = urllib.parse.parse_qs(self.rfile.read(int(self.headers.get('Content-Length', 0))).decode())
        g = lambda k: q.get(k, [''])[0].strip().lower()
        lines = open(SESS).read().lower().splitlines() if os.path.exists(SESS) else []
        ok = []
        for i in (1, 2):
            idx, mac, user = g('idx%d' % i), g('mac%d' % i), g('user%d' % i)
            if idx and mac and user and any(('receiver_index=' + idx in l and 'mac=' + mac in l and 'user=' + user in l) for l in lines):
                ok.append({'receiver_index': idx, 'mac': mac, 'user': user})
        t = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'peers': ok, 'status': 'TICKET_SUBMITTED' if len(ok) >= 2 else 'TICKET_REJECTED'}
        open('/home/ubuntu/forensics_ticket.json', 'w').write(json.dumps(t, indent=2) + '\n')
        self.page('<pre>' + html.escape(json.dumps(t, indent=2)) + '</pre>')
HTTPServer(('0.0.0.0', 5001), H).serve_forever()
