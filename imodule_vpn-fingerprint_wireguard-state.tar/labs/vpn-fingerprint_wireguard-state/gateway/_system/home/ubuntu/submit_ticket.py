#!/usr/bin/env python3
import json
t = {"peers": [{"ip":"10.0.1.101","user":"nguyen_rd_1","idx":"0xaabbcc01"},{"ip":"10.0.1.102","user":"tran_rd_2","idx":"0xddeeff02"}], "status":"TICKET_SUBMITTED"}
open('/home/ubuntu/forensics_ticket.json', 'w').write(json.dumps(t, indent=2) + '\n')
print("TICKET_SUBMITTED_SUCCESSFULLY")
