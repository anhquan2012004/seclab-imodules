#!/usr/bin/env python3
import sys, math
from collections import Counter
from scapy.all import rdpcap, UDP, Raw
pcap = sys.argv[1] if len(sys.argv)>1 else '/home/ubuntu/pcaps/5_wg_prefix_obf.pcap'
raw_bytes = b''.join(bytes(p[Raw].load) for p in rdpcap(pcap) if p.haslayer(UDP) and p.haslayer(Raw))
cnt = Counter(raw_bytes); total = len(raw_bytes)
ent = -sum((c/total)*math.log2(c/total) for c in cnt.values()) if total else 0.0
status = "PREFIX_OBFUSCATION_DETECTED" if ent > 6.5 else "LOW_ENTROPY"
print(f"ANALYZED_BYTES={total} | SHANNON_ENTROPY={ent:.4f}_BITS_PER_BYTE | {status}")
