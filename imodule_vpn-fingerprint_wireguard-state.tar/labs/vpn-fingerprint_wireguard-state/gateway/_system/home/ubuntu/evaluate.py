#!/usr/bin/env python3
import os, re, subprocess
H = '/home/ubuntu/'
a, b, srv, corp = '10.0.1.101', '10.0.1.102', '10.0.2.10', '10.0.2.20'
T = [('1_http_clean.pcap', {(a, corp): False}), ('2_wg_long.pcap', {(a, srv): True}),
     ('3_wg_port.pcap', {(a, srv): True}), ('4_wg_mixed.pcap', {(a, srv): True, (b, corp): True, (b, srv): False})]
tp = fp = tn = fn = 0
if '__' in open(H + 'rules/wg_stateful.rules').read():
    print('RULES_INCOMPLETE: dien not cac cho __ trong ~/rules/wg_stateful.rules'); raise SystemExit(1)
for i, (pc, truth) in enumerate(T):
    path = H + 'pcaps/' + pc
    if not os.path.exists(path): print('MISSING ' + pc); raise SystemExit(1)
    d = '/tmp/eval_%d' % i
    subprocess.run(['sudo', 'rm', '-rf', d]); os.makedirs(d)
    o = subprocess.run(['sudo', 'suricata', '-r', path, '-S', H + 'rules/wg_stateful.rules', '-l', d, '-k', 'none'], capture_output=True, text=True)
    if re.search(r'^E:', o.stdout + o.stderr, re.M):
        print('RULES_INVALID: Suricata bao loi cu phap luat'); raise SystemExit(1)
    hits = set()
    if os.path.exists(d + '/fast.log'):
        for l in open(d + '/fast.log'):
            m = re.search(r'\{UDP\} ([\d.]+):\d+ -> ([\d.]+):\d+', l)
            if m: hits.add(frozenset(m.groups()))
    known = {frozenset(k) for k in truth}
    for k, pos in truth.items():
        h = frozenset(k) in hits
        if pos and h: tp += 1
        elif pos: fn += 1
        elif h: fp += 1
        else: tn += 1
    fp += len(hits - known)
acc = 100.0 * (tp + tn) / max(tp + tn + fp + fn, 1)
txt = "Confusion Matrix (Flow-level):\nTP = %d  FN = %d  FP = %d  TN = %d\nAccuracy = %.1f%%\n" % (tp, fn, fp, tn, acc)
if tp == 4 and fn == 0 and fp == 0 and tn == 2: txt += "LAB_WG_STATE_PASS\n"
open(H + 'eval_metrics.txt', 'w').write(txt); print(txt)
