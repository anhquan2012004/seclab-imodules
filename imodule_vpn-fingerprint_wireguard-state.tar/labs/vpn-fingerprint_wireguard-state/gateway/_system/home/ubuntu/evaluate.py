#!/usr/bin/env python3
import os, subprocess
H = '/home/ubuntu/'
S = [('1_http_clean.pcap', 'wg_stateful.rules', [('10.0.1.101', 0)]),
     ('2_wg_clean.pcap', 'wg_stateful.rules', [('10.0.1.101', 1)]),
     ('3_wg_with_decoy.pcap', 'wg_stateful.rules', [('10.0.1.101', 1), ('10.0.1.150', 0)]),
     ('4_wg_tail_padded.pcap', 'wg_anti_padding.rules', [('10.0.1.101', 1)])]
tp = fp = tn = fn = 0
for i, (pc, rl, flows) in enumerate(S):
    if not (os.path.exists(H + 'pcaps/' + pc) and os.path.exists(H + 'rules/' + rl)):
        print('MISSING: %s or %s' % (pc, rl)); raise SystemExit(1)
    d = '/tmp/eval_%d' % i
    subprocess.run(['sudo', 'rm', '-rf', d]); os.makedirs(d)
    subprocess.run(['sudo', 'suricata', '-r', H + 'pcaps/' + pc, '-S', H + 'rules/' + rl, '-l', d, '-k', 'none'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log = open(d + '/fast.log').read() if os.path.exists(d + '/fast.log') else ''
    for ip, truth in flows:
        hit = ip in log
        if truth and hit: tp += 1
        elif truth: fn += 1
        elif hit: fp += 1
        else: tn += 1
acc = round(100.0 * (tp + tn) / (tp + tn + fp + fn), 1)
print("Confusion Matrix (Flow-level):\nTP = %d  FN = %d  FP = %d  TN = %d\nAccuracy = %s%%" % (tp, fn, fp, tn, acc))
if fn == 0 and fp == 0 and tp == 3 and tn == 2: print("LAB_WG_STATE_PASS")
