#!/usr/bin/env python3
import glob, json, html
from http.server import BaseHTTPRequestHandler, HTTPServer
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        rows = []
        for p in sorted(glob.glob('/home/ubuntu/logs_*/eve.json')):
            for line in open(p, errors='ignore'):
                try: e = json.loads(line)
                except ValueError: continue
                if e.get('event_type') == 'alert':
                    rows.append((e.get('timestamp', ''), e.get('src_ip', ''), e.get('dest_ip', ''), e.get('alert', {}).get('signature', ''), p.split('/')[3]))
        tr = ''.join('<tr>' + ''.join('<td>%s</td>' % html.escape(str(c)) for c in r) + '</tr>' for r in rows)
        page = '<html><head><title>SOC Alert Viewer</title><meta http-equiv="refresh" content="5"></head><body><h1>PTIT SOC Alert Viewer (eve.json)</h1><p>Alerts: %d</p><table border=1><tr><th>Time</th><th>Src</th><th>Dst</th><th>Signature</th><th>Log dir</th></tr>%s</table></body></html>' % (len(rows), tr)
        self.send_response(200); self.send_header('Content-type', 'text/html; charset=utf-8'); self.end_headers()
        self.wfile.write(page.encode())
HTTPServer(('0.0.0.0', 5000), H).serve_forever()
