#!/usr/bin/env python3
import sys, json, os, time, collections
from scapy.all import rdpcap, sniff, UDP, Raw, IP
if len(sys.argv) > 2 and sys.argv[1] == '--live':
    pcap = 'live:eth0'; pkts = sniff(iface='eth0', filter='udp', timeout=int(sys.argv[2]))
else:
    pcap = sys.argv[1] if len(sys.argv) > 1 else '/home/ubuntu/pcaps/7_wg_long.pcap'; pkts = rdpcap(pcap)
state = 'IDLE'; trans = []; inits = []; kas = []; src = ''
for p in pkts:
    if not (p.haslayer(IP) and p.haslayer(UDP) and p.haslayer(Raw)): continue
    b = bytes(p[Raw].load); t = float(p.time); n = len(b)
    if b[:4] == b'\x01\x00\x00\x00' and n >= 148:
        inits.append(t); state = 'INIT_SENT'; trans.append('INIT_SENT'); src = src or p[IP].src
    elif b[:4] == b'\x02\x00\x00\x00' and n >= 92 and state == 'INIT_SENT':
        state = 'ESTABLISHED'; trans.append('ESTABLISHED')
    elif b[:4] == b'\x04\x00\x00\x00' and state in ('ESTABLISHED', 'DATA_TRANSFER'):
        if state == 'ESTABLISHED': trans.append('DATA_TRANSFER')
        state = 'DATA_TRANSFER'
        if n == 32 and p[IP].src.startswith('10.0.1.'): kas.append(t)
iats = [round(y - x) for x, y in zip(kas, kas[1:])]
peak = collections.Counter(iats).most_common(1)[0][0] if iats else 0
rk = [round(y - x) for x, y in zip(inits, inits[1:])]
rekey = rk[0] if rk else 0
status = 'REKEY_DETECTED' if rk and 100 <= rekey <= 140 else 'NO_REKEY_OBSERVED'
rep = {"source": pcap, "handshake_inits": len(inits), "keepalive_32B_count": len(kas), "keepalive_iat_peak_sec": peak, "rekey_interval_sec": rekey, "transitions": trans[:4], "status": status}
open('/home/ubuntu/scapy_state_report.json', 'w').write(json.dumps(rep, indent=2) + '\n')
if status == 'REKEY_DETECTED':
    os.makedirs('/home/ubuntu/logs_detector', exist_ok=True)
    ev = {"timestamp": time.strftime('%Y-%m-%dT%H:%M:%S'), "event_type": "alert", "src_ip": src, "dest_ip": "10.0.2.10", "alert": {"signature": "[PTIT-SCAPY] WireGuard keepalive IAT=%ss rekey=%ss" % (peak, rekey)}}
    open('/home/ubuntu/logs_detector/eve.json', 'a').write(json.dumps(ev) + '\n')
print(json.dumps(rep, indent=2))
