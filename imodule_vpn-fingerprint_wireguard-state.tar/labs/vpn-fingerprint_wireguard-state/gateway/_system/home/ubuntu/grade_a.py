#!/usr/bin/env python3
import os
H = os.path.expanduser('~/')
G = [('DAUVANTAY', 'Dau van tay goi va may trang thai (Task 3-4)', [('sizes', 'wg_packet_sizes.txt chua "INITIATION_payload=148"', 'wg_packet_sizes.txt', 'INITIATION_payload=148'), ('state', 'scapy_state_report.json chua "REKEY_DETECTED"', 'scapy_state_report.json', 'REKEY_DETECTED')]), ('LUAT', 'Luat theo cong, mot goi, hai tang (Task 5-7)', [('port', 'logs_port/summary.txt chua "ALERTS=0"', 'logs_port/summary.txt', 'ALERTS=0'), ('single', 'logs_single/fast.log chua "2026301"', 'logs_single/fast.log', '2026301'), ('stateful', 'logs_stateful/fast.log chua "2026303"', 'logs_stateful/fast.log', '2026303')]), ('TRUYVET', 'Truy vet va chung cu (Task 8-9)', [('peers', 'peers_report.txt chua "ENDPOINT=10.0.2.20"', 'peers_report.txt', 'ENDPOINT=10.0.2.20'), ('evidence', 'evidence/chain_of_custody.csv chua "2_wg_long.pcap"', 'evidence/chain_of_custody.csv', '2_wg_long.pcap')]), ('KETLUAN', 'Bien ban va ma tran nham lan (Task 10)', [('ticket', 'forensics_ticket.json chua "TICKET_SUBMITTED"', 'forensics_ticket.json', 'TICKET_SUBMITTED'), ('eval', 'eval_metrics.txt chua "LAB_WG_STATE_PASS"', 'eval_metrics.txt', 'LAB_WG_STATE_PASS')])]
def has(f, s):
    p = H + f
    return os.path.exists(p) and s in open(p, errors='ignore').read()
out = []; allok = True
for tag, title, items in G:
    res = [(i, has(i[2], i[3])) for i in items]; n = sum(r for _, r in res)
    out.append('== %s: %s ==' % (tag, title))
    for i, r in res: out.append('  [%s] %-11s %s' % ('OK   ' if r else 'THIEU', i[0], i[1]))
    ok = n == len(items); allok = allok and ok
    out.append('NHOM_%s=%s %d/%d' % (tag, 'OK' if ok else 'THIEU', n, len(items)))
if allok: out.append('LAB_A_COMPLETE')
open(H + 'grade_a.txt', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
