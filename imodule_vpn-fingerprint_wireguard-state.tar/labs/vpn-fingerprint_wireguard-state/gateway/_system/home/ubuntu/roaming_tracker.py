#!/usr/bin/env python3
import sys
from scapy.all import rdpcap, IP, UDP, Raw
pcap = sys.argv[1] if len(sys.argv)>1 else '/home/ubuntu/pcaps/6_wg_roaming.pcap'
idx_ips = {}
for p in rdpcap(pcap):
  if p.haslayer(IP) and p.haslayer(UDP) and p.haslayer(Raw):
    b = bytes(p[Raw].load)
    if b[:4] == b'\x04\x00\x00\x00' and p[IP].src.startswith('10.0.1.'):
      idx = '0x' + b[4:8].hex()
      idx_ips.setdefault(idx, [])
      if p[IP].src not in idx_ips[idx]: idx_ips[idx].append(p[IP].src)
for idx, ips in idx_ips.items():
  if len(ips) >= 2:
    print(f"ROAMING_CONFIRMED: {' -> '.join(ips)} | INVARIANT_RECEIVER_INDEX={idx}")
