#!/bin/bash
mkdir -p ~/evidence; cd ~/pcaps || exit 1
sha256sum *.pcap > ~/evidence/SHA256SUMS
echo "item,sha256,first_packet_utc,last_packet_utc,collected_by,collected_at" > ~/evidence/chain_of_custody.csv
for f in *.pcap; do
  h=$(sha256sum "$f" | cut -d' ' -f1)
  a=$(tshark -r "$f" -T fields -e frame.time_epoch 2>/dev/null | head -1 | cut -d. -f1)
  z=$(tshark -r "$f" -T fields -e frame.time_epoch 2>/dev/null | tail -1 | cut -d. -f1)
  echo "$f,$h,$(date -u -d @${a:-0} +%FT%TZ),$(date -u -d @${z:-0} +%FT%TZ),$(whoami),$(date -u +%FT%TZ)" >> ~/evidence/chain_of_custody.csv
done
cp ~/peers_report.txt ~/scapy_state_report.json ~/evidence/ 2>/dev/null
(cd ~/pcaps && sha256sum -c ~/evidence/SHA256SUMS)
cat ~/evidence/chain_of_custody.csv
