#!/usr/bin/env python3
import sys, sqlite3
from scapy.all import rdpcap, IP, UDP, Raw
pcap = sys.argv[1] if len(sys.argv)>1 else '/home/ubuntu/pcaps/multi_peer.pcap'
peers = {}
for p in rdpcap(pcap):
  if p.haslayer(IP) and p.haslayer(UDP) and p.haslayer(Raw):
    b = bytes(p[Raw].load)
    if b[:4] in [b'\x01\x00\x00\x00', b'\x04\x00\x00\x00'] and p[IP].src.startswith('10.0.1.'):
      idx = '0x' + b[4:8].hex()
      peers[idx] = p[IP].src
conn = sqlite3.connect('/home/ubuntu/idm.db').cursor()
for idx, ip in sorted(peers.items()):
  r = conn.execute("SELECT mac, user, dept FROM devices WHERE ip=?", (ip,)).fetchone()
  if r: print(f"RECEIVER_INDEX={idx} | IP={ip} | MAC={r[0]} | USER={r[1]} | DEPT={r[2]}")
