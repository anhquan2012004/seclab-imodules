# Dien so byte cua tung truong theo dac ta WireGuard (moi cho trong la mot so nguyen).
# 'static' va 'timestamp' da gom ca the xac thuc (tag) cua chung.
INIT = dict(type=__, reserved=__, sender=__, ephemeral=__, static=__, timestamp=__, mac1=__, mac2=__)
RESP = dict(type=__, reserved=__, sender=__, receiver=__, ephemeral=__, empty=__, mac1=__, mac2=__)
DATA_HEADER = dict(type=__, reserved=__, receiver=__, counter=__)
AEAD_TAG = __
