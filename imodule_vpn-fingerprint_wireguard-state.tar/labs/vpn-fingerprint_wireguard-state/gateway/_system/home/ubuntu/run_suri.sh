#!/bin/bash
[ $# -eq 3 ] || { echo "usage: run_suri.sh PCAP RULES LOGDIR"; exit 1; }
grep -q '__' "$2" && { echo "RULES_INCOMPLETE: file luat con cho trong __"; exit 1; }
sudo rm -rf "$3"; mkdir -p "$3"
sudo suricata -r "$1" -S "$2" -l "$3" -k none > /tmp/suri_run.log 2>&1
if grep -q '^E:' /tmp/suri_run.log; then grep '^E:' /tmp/suri_run.log | head -3; echo "RULES_INVALID: sua cu phap luat roi chay lai"; rm -rf "$3"; exit 1; fi
[ -f "$3/fast.log" ] || sudo touch "$3/fast.log"
echo "PCAP=$(basename $1) RULES=$(basename $2) ALERTS=$(wc -l < $3/fast.log)" | tee "$3/summary.txt"
