#!/usr/bin/env python3
import sys, sqlite3
from scapy.all import rdpcap, Ether, IP, UDP, Raw
if len(sys.argv) < 2: sys.exit("usage: wg_peers.py PCAP")
inits = {}; resp = set()
for p in rdpcap(sys.argv[1]):
    if not (p.haslayer(IP) and p.haslayer(UDP) and p.haslayer(Raw)): continue
    b = bytes(p[Raw].load)
    if len(b) == 148 and b[:4] == b'\x01\x00\x00\x00':
        inits[b[4:8]] = (p[IP].src, p[Ether].src, p[IP].dst, p[UDP].dport)
    elif len(b) == 92 and b[:4] == b'\x02\x00\x00\x00':
        resp.add(b[8:12])
db = sqlite3.connect('/home/ubuntu/idm.db'); out = []
for idx, (ip, mac, dst, dp) in inits.items():
    if idx not in resp: continue
    r = db.execute('select user, dept from devices where mac=?', (mac,)).fetchone() or ('?', '?')
    out.append('SENDER_INDEX=0x%s IP=%s MAC=%s USER=%s DEPT=%s ENDPOINT=%s:%d' % (idx.hex(), ip, mac, r[0], r[1], dst, dp))
open('/home/ubuntu/peers_report.txt', 'w').write('\n'.join(sorted(out)) + '\n')
print('\n'.join(sorted(out)))
