#!/usr/bin/env python3
import sys
from scapy.all import rdpcap, IP, UDP, Raw
if len(sys.argv) < 2: sys.exit('usage: wg_jitter_report.py PCAP')
t = []
for p in rdpcap(sys.argv[1]):
    if p.haslayer(IP) and p.haslayer(UDP) and p.haslayer(Raw) and p[IP].src.startswith('10.0.1.'):
        b = bytes(p[Raw].load)
        if len(b) == 32 and b[:4] == b'\x04\x00\x00\x00': t.append(float(p.time))
iat = [y - x for x, y in zip(t, t[1:])]
if len(iat) < 3: sys.exit('Khong du keepalive 32B (can PCAP dai >= 60 giay): %d goi' % len(t))
n = len(iat); strict = sum(abs(i - 10) <= 0.5 for i in iat) / n; win = sum(7 <= i <= 13 for i in iat) / n
mean = sum(iat) / n; sd = (sum((i - mean) ** 2 for i in iat) / n) ** 0.5
v = 'RHYTHM_STRICT' if strict >= 0.8 else ('RHYTHM_WINDOW_ONLY (co jitter, can nho nguong)' if win >= 0.8 else 'RHYTHM_LOST (jitter lon, can dac trung khac)')
out = 'PCAP=%s keepalive=%d iat_mean=%.2fs iat_stdev=%.2fs strict(10+-0.5s)=%.0f%% window(7-13s)=%.0f%% VERDICT=%s' % (sys.argv[1].split('/')[-1], len(t), mean, sd, strict * 100, win * 100, v)
open('/home/ubuntu/jitter_report.txt', 'a').write(out + '\n'); print(out)
