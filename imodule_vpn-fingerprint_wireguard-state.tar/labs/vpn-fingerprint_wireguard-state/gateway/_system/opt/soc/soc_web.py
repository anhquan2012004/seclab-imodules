#!/usr/bin/env python3
import glob, html, json, os, sqlite3, time, urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
H = '/home/ubuntu/'
ACT = {'10.0.1.101': '10.0.2.10', '10.0.1.102': '10.0.2.20'}
def approved():
    return {l.split(',')[0].strip() for l in open(H + 'approved_vpn.csv') if l.strip() and not l.startswith('#')}
FORM = ''.join('<p>Nhân viên %d: IP <input name="ip%d"> MAC <input name="mac%d"> User <input name="user%d"> Endpoint <input name="ep%d"> Kết luận <select name="v%d"><option>VIOLATION</option><option>COMPLIANT</option></select></p>' % ((i,) * 6) for i in (1, 2))
class S(BaseHTTPRequestHandler):
    def page(self, body):
        self.send_response(200); self.send_header('Content-type', 'text/html; charset=utf-8'); self.end_headers()
        self.wfile.write(('<html><head><title>PTIT SOC</title></head><body><h1>PTIT SOC</h1>' + body + '</body></html>').encode())
    def do_GET(self):
        out = ''
        for d in sorted(glob.glob(H + 'logs_*')):
            s = ''
            for f in ('summary.txt', 'fast.log'):
                if os.path.exists(d + '/' + f): s += open(d + '/' + f, errors='ignore').read()
            out += '<h3>%s</h3><pre>%s</pre>' % (html.escape(os.path.basename(d)), html.escape(s))
        rows = sqlite3.connect(H + 'idm.db').execute('select ip, mac, user, dept from devices').fetchall()
        out += '<h2>Thiết bị (IdM)</h2><pre>' + html.escape('\n'.join(' | '.join(r) for r in rows)) + '</pre>'
        self.page(out + '<h2>Nộp biên bản</h2><form method="POST" action="/ticket">' + FORM + '<button type="submit">Submit Ticket</button></form>')
    def do_POST(self):
        q = urllib.parse.parse_qs(self.rfile.read(int(self.headers.get('Content-Length', 0))).decode())
        g = lambda k: q.get(k, [''])[0].strip().lower()
        db = sqlite3.connect(H + 'idm.db'); ap = approved(); ok = []; bad = []
        for i in (1, 2):
            ip = g('ip%d' % i); r = db.execute('select mac, user from devices where ip=?', (ip,)).fetchone()
            truth = 'compliant' if ACT.get(ip) in ap else 'violation'
            why = []
            if not r: why.append('ip')
            else:
                if r[0].lower() != g('mac%d' % i): why.append('mac')
                if r[1].lower() != g('user%d' % i): why.append('user')
            if g('ep%d' % i).split(':')[0] != ACT.get(ip): why.append('endpoint')
            if g('v%d' % i) != truth: why.append('ket_luan (doi chieu approved_vpn.csv)')
            if why: bad.append('nhan_vien_%d: sai %s' % (i, ', '.join(why)))
            else: ok.append(ip)
        t = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'accepted': ok, 'errors': bad, 'status': 'TICKET_SUBMITTED' if len(set(ok)) == 2 else 'TICKET_REJECTED'}
        open(H + 'forensics_ticket.json', 'w').write(json.dumps(t, indent=2) + '\n')
        self.page('<pre>' + html.escape(json.dumps(t, indent=2)) + '</pre>')
HTTPServer(('0.0.0.0', 5000), S).serve_forever()
