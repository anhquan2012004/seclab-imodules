#!/usr/bin/env python3
import os, socket, time
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
for _ in range(5):
    s.sendto(b'\x01\x00\x00\x00' + os.urandom(144), ('10.0.2.10', 51820))
    time.sleep(0.2)
print('NOISE_SENT')
