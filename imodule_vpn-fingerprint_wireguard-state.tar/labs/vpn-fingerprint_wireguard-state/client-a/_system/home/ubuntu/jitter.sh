#!/bin/bash
case "$1" in
  on) sudo tc qdisc replace dev eth0 root netem delay ${2:-1500}ms ${3:-1200}ms && echo "JITTER_ON delay=${2:-1500}ms jitter=${3:-1200}ms" || echo "JITTER_FAILED: kernel khong ho tro netem" ;;
  off) sudo tc qdisc del dev eth0 root 2>/dev/null; echo JITTER_OFF ;;
  show) tc qdisc show dev eth0 ;;
  *) echo "usage: jitter.sh on [delay_ms] [jitter_ms] | off | show" ;;
esac
