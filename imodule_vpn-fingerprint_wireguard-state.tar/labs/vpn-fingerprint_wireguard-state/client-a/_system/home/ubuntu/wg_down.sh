#!/bin/bash
[ "$(id -u)" = 0 ] || exec sudo "$0" "$@"
ip link del wg0 && echo WG_DOWN_OK
