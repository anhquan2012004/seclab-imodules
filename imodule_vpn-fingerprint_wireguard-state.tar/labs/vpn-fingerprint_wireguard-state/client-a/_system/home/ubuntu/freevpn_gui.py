#!/usr/bin/env python3
import sys, subprocess
if '--hop' in sys.argv:
  for p in ['51821', '51822', '51823']:
    subprocess.run(['/usr/local/bin/wg_sim', 'clean', p, 'aabbcc01'])
  sys.exit(0)
if '--connect' in sys.argv:
  m = sys.argv[sys.argv.index('--connect')+1] if len(sys.argv)>2 else 'clean'
  subprocess.run(['/usr/local/bin/wg_sim', m, '51820', 'aabbcc01'])
  sys.exit(0)
try:
  import tkinter as tk
  r = tk.Tk(); r.title('FreeVPN - WireGuard Stealth Client')
  tk.Label(r, text='WireGuard R&D Client (10.0.1.101)', font=('Arial',12,'bold')).pack(padx=15,pady=8)
  tk.Button(r, text='Connect Standard WG (51820)', command=lambda: subprocess.Popen(['/usr/local/bin/wg_sim','clean','51820'])).pack(fill='x',padx=15,pady=4)
  tk.Button(r, text='Hop Port 3x (51821-51823)', command=lambda: subprocess.Popen(['python3','/home/ubuntu/freevpn_gui.py','--hop'])).pack(fill='x',padx=15,pady=4)
  tk.Button(r, text='Connect Tail-Padding Relay', command=lambda: subprocess.Popen(['/usr/local/bin/wg_sim','tail','51820'])).pack(fill='x',padx=15,pady=4)
  tk.Button(r, text='Connect Prefix-Obfuscation Relay', command=lambda: subprocess.Popen(['/usr/local/bin/wg_sim','prefix','51820'])).pack(fill='x',padx=15,pady=4)
  r.mainloop()
except Exception as e:
  subprocess.run(['/usr/local/bin/wg_sim', 'clean', '51820', 'aabbcc01'])
