#!/usr/bin/env python3
import subprocess, tkinter as tk
r = tk.Tk(); r.title('FreeVPN (WireGuard)')
v = tk.StringVar(value='DISCONNECTED'); p = tk.StringVar(value='51820')
def run(cmd):
    o = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    v.set((o.stdout + o.stderr).strip()[-300:] or 'done')
tk.Label(r, text='FreeVPN - cong', font=('Arial', 12, 'bold')).pack(padx=20, pady=6)
tk.Entry(r, textvariable=p).pack(padx=20)
tk.Button(r, text='Connect', command=lambda: run('~/wg_up.sh ' + p.get())).pack(fill='x', padx=20, pady=3)
tk.Button(r, text='Disconnect', command=lambda: run('~/wg_down.sh')).pack(fill='x', padx=20, pady=3)
tk.Button(r, text='Status', command=lambda: run('sudo wg show wg0 | head -8')).pack(fill='x', padx=20, pady=3)
tk.Label(r, textvariable=v, wraplength=300, justify='left').pack(padx=20, pady=8)
r.mainloop()
