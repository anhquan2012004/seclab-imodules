#!/bin/bash
[ "$(id -u)" = 0 ] || exec sudo "$0" "$@"
PORT=${1:-51820}
ip link del wg0 2>/dev/null
ip link add wg0 type wireguard || exit 1
sed -E "s/^(Endpoint *= *[0-9.]+):[0-9]+/\1:$PORT/" /home/ubuntu/wg_client.conf > /tmp/wg_run.conf
wg setconf wg0 /tmp/wg_run.conf
ip addr add 10.9.0.2/24 dev wg0
ip link set wg0 up
ip route replace 10.0.2.20/32 dev wg0
echo "WG_UP_OK port=$PORT"
