#!/usr/bin/env python3
import sys, subprocess
mode = 'tail' if 'tail' in sys.argv else ('prefix' if 'prefix' in sys.argv else 'clean')
subprocess.run(['/usr/local/bin/wg_sim', mode, '51820', 'aabbcc01'])
