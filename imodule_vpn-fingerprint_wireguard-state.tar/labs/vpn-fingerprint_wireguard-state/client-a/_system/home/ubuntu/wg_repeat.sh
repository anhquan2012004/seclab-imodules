#!/bin/bash
N=${1:-10}
for i in $(seq 1 $N); do ~/wg_down.sh > /dev/null 2>&1; ~/wg_up.sh > /dev/null; ping -c 1 -W 2 10.9.0.1 > /dev/null; sleep 1; done
~/wg_down.sh > /dev/null 2>&1
echo "REPEAT_DONE n=$N"
