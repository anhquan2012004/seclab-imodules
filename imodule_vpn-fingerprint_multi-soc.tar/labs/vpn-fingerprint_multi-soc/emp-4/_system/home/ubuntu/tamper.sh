#!/bin/bash
logger -t shadowtun "marker-$(date +%s) ssh -D 1080 toi 10.0.2.10"
sleep 2
sudo sh -c ': > /var/log/syslog'
history -c; : > ~/.bash_history
echo TAMPER_DONE
