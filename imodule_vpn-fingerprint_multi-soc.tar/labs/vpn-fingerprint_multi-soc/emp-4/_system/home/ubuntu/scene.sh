#!/bin/bash
N=${1:-3}
for i in $(seq 1 $N); do
  ~/tunnel.sh https > /dev/null; ~/tunnel.sh dot > /dev/null; ~/tunnel.sh squid-test > /dev/null
  python3 ~/netgen.py voip 14 > /dev/null &
  python3 ~/netgen.py quic 14 > /dev/null &
  curl -s -o /dev/null --limit-rate 150k -m 14 http://10.0.2.30/big.bin &
  ~/tunnel.sh ssh-load 4 > /dev/null &
  ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i ~/.ssh/id_ed25519 ubuntu@intranet.ptit.local 'sleep 6' > /dev/null 2>&1
  wait
done
echo SCENE_DONE
