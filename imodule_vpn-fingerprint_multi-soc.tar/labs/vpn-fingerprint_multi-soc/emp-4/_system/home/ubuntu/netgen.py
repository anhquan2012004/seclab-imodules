#!/usr/bin/env python3
import os, random, socket, sys, time
mode = sys.argv[1]; dur = float(sys.argv[2]) if len(sys.argv) > 2 else 12
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); t0 = time.time()
if mode == 'voip':
    while time.time() - t0 < dur: s.sendto(os.urandom(160), ('10.0.2.30', 5004)); time.sleep(0.02)
elif mode == 'quic':
    s.sendto(os.urandom(1200), ('10.0.2.30', 443))
    while time.time() - t0 < dur: time.sleep(random.uniform(0.1, 0.6)); s.sendto(os.urandom(random.choice([80, 120, 600])), ('10.0.2.30', 443))
print('NETGEN_DONE', mode)
