#!/bin/bash
N=${1:-6}
for i in $(seq 1 $N); do
  ~/tunnel.sh https > /dev/null; ~/tunnel.sh dot > /dev/null; ~/tunnel.sh admin > /dev/null; ~/tunnel.sh squid-test > /dev/null; ~/tunnel.sh ssh-load 5 > /dev/null
  python3 ~/netgen.py voip 12; python3 ~/netgen.py quic 12
  curl -s -o /dev/null --limit-rate 150k -m 14 http://10.0.2.30/big.bin; sleep 2
done
echo BULK_DONE
