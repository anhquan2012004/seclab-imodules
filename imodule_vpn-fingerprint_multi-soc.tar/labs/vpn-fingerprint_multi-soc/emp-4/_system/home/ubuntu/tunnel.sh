#!/bin/bash
S="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i $HOME/.ssh/id_ed25519"
case "$1" in
  ssh-up) ssh -f -N -D 1080 $S ubuntu@10.0.2.10 && echo SSH_D_UP ;;
  ssh-down) pkill -f "ssh -f -N -D" ; echo SSH_D_DOWN ;;
  ssh-test) curl -s -m 5 --socks5-hostname 127.0.0.1:1080 http://www.weibo.com ;;
  squid-test) curl -s -m 5 -x http://10.0.2.10:3128 http://www.weibo.com ;;
  admin) ssh $S ubuntu@intranet.ptit.local 'echo ADMIN_OK; uptime' ;;
  https) curl -sk -m 5 https://intranet.ptit.local/ ;;
  dot) kdig @10.0.2.10 +tls www.weibo.com +short ;;
  ssh-load) ssh -f -N -D 1080 $S ubuntu@10.0.2.10; for i in $(seq 1 ${2:-5}); do curl -s -m 3 -o /dev/null --socks5-hostname 127.0.0.1:1080 http://www.weibo.com; sleep 3; done; pkill -f "ssh -f -N -D"; echo SSH_LOAD_DONE ;;
  *) echo "usage: tunnel.sh ssh-up|ssh-down|ssh-test|ssh-load|squid-test|admin|https|dot" ;;
esac
