#!/bin/bash
M=${1:-base}; N=${2:-2}
case "$M" in *jitter*) ~/jitter.sh on ;; esac
for i in $(seq 1 $N); do
  case "$M" in portswap) A=53 ;; *) A=443 ;; esac
  ~/vpn.sh up $A > /dev/null; sleep 40; ~/vpn.sh down > /dev/null; sleep 3
done
~/jitter.sh off > /dev/null; echo EVASION_DONE $M
