#!/bin/bash
run() { case "$1" in *jitter*) ~/jitter.sh on > /dev/null ;; esac; ~/vpn.sh up $2 > /dev/null; sleep 13; ~/vpn.sh down > /dev/null; ~/jitter.sh off > /dev/null; sleep 2; }
~/vpn.sh down > /dev/null 2>&1; ~/jitter.sh off > /dev/null 2>&1; sleep 1
run portswap 53; run jitter 443; run nested 443; run nested_jitter 443
echo EVADE_DONE
