#!/bin/bash
[ "$(id -u)" = 0 ] || exec sudo "$0" "$@"
case "$1" in
  up) sed -E "s/^(Endpoint *= *[0-9.]+):[0-9]+/\1:${2:-443}/" /etc/wireguard/wg0.conf > /tmp/wg_run.conf; ip link del wg0 2>/dev/null; ip link add wg0 type wireguard && wg setconf wg0 /tmp/wg_run.conf && ip addr add 10.9.0.2/24 dev wg0 && ip link set wg0 up && ip route replace 10.0.2.20/32 dev wg0 && echo WG_UP ;;
  down) ip link del wg0 && echo WG_DOWN ;;
  status) wg show wg0 | head -8; ip route get 10.0.2.20 ;;
  *) echo "usage: vpn.sh up [cong]|down|status" ;;
esac
