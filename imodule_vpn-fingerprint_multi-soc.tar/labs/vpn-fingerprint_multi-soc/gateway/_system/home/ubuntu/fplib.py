#!/usr/bin/env python3
import collections, math, os
from scapy.all import rdpcap, IP, TCP, UDP
VPN = ('OPENVPN', 'WIREGUARD', 'IPSEC')
def rebuild(segs):
    out = b''; nxt = None
    for sq, d in sorted(set(segs)):
        if nxt is None: nxt = sq
        if sq > nxt: break
        if sq + len(d) <= nxt: continue
        out += d[nxt - sq:]; nxt = sq + len(d)
    return out
def ovpn(b):
    i = n = 0
    while i + 3 <= len(b):
        L = int.from_bytes(b[i:i + 2], 'big'); op = b[i + 2] >> 3
        if not (1 <= L <= 1700 and 1 <= op <= 11): break
        n += 1; i = min(i + 2 + L, len(b))
    return n, i
def tls(b):
    i = n = 0
    while i + 5 <= len(b):
        L = int.from_bytes(b[i + 3:i + 5], 'big')
        if not (0x14 <= b[i] <= 0x18 and b[i + 1] == 3 and b[i + 2] <= 4 and L <= 16645): break
        n += 1; i = min(i + 5 + L, len(b))
    return n, i
def wg_ok(d):
    if len(d) < 32 or d[1:4] != b'\0\0\0': return False
    t = d[0]
    return (t == 1 and len(d) == 148) or (t == 2 and len(d) == 92) or (t == 3 and len(d) == 64) or (t == 4 and (len(d) - 32) % 16 == 0)
def ike_ok(d):
    if d[:4] == b'\0\0\0\0': d = d[4:]
    return len(d) >= 28 and d[17] == 0x20 and d[18] in (34, 35, 36, 37) and int.from_bytes(d[24:28], 'big') == len(d)
class Unit:
    def __init__(s, key): s.key = key; s.c2s = []; s.segs = []; s.t0 = None; s.t1 = None; s.s2c_bytes = 0; s.s2c_pkts = 0; s.esp = []
def units(path):
    U = {}
    for p in rdpcap(path):
        if not p.haslayer(IP): continue
        ip = p[IP]; a, b = ip.src, ip.dst
        if a.startswith('10.0.1.') and b.startswith('10.0.2.'): c2s = True; cl, sv = a, b
        elif a.startswith('10.0.2.') and b.startswith('10.0.1.'): c2s = False; cl, sv = b, a
        else: continue
        t = float(p.time); seq = None
        if ip.proto == 50:
            if not c2s: continue
            d = bytes(ip.payload); key = ('esp', cl, 0, sv, 0, int.from_bytes(d[:4], 'big'))
        elif p.haslayer(TCP):
            l4 = p[TCP]; d = bytes(l4.payload); seq = l4.seq; key = ('tcp', cl, l4.sport if c2s else l4.dport, sv, l4.dport if c2s else l4.sport, 0)
        elif p.haslayer(UDP):
            l4 = p[UDP]; d = bytes(l4.payload); key = ('udp', cl, l4.sport if c2s else l4.dport, sv, l4.dport if c2s else l4.sport, 0)
        else: continue
        u = U.setdefault(key, Unit(key)); u.t0 = t if u.t0 is None else min(u.t0, t); u.t1 = t if u.t1 is None else max(u.t1, t)
        if c2s:
            if d: u.c2s.append((t, d))
            if seq is not None and d: u.segs.append((seq, d))
            if key[0] == 'esp': u.esp.append(int.from_bytes(d[4:8], 'big'))
        else: u.s2c_bytes += len(d); u.s2c_pkts += 1
    return {k: u for k, u in U.items() if not (k[0] == 'udp' and k[2] in (500, 4500) and k[4] in (500, 4500))}
def truth(k):
    pr, cl, cp, sv, sp, spi = k
    if cl == '10.0.1.101' and pr == 'tcp' and sv == '10.0.2.10': return 'OPENVPN'
    if cl == '10.0.1.102' and pr == 'udp' and sv == '10.0.2.10': return 'WIREGUARD'
    if cl == '10.0.1.103' and pr == 'esp': return 'IPSEC'
    if cl == '10.0.1.104':
        if pr == 'tcp' and sv == '10.0.2.30' and sp == 443: return 'HTTPS'
        if pr == 'tcp' and sv == '10.0.2.30' and sp == 22: return 'SSH_ADMIN'
        if pr == 'tcp' and sv == '10.0.2.10' and sp == 853: return 'DOT'
        if pr == 'tcp' and sv == '10.0.2.10' and sp == 3128: return 'SQUID'
        if pr == 'tcp' and sv == '10.0.2.10' and sp == 22: return 'SSH_TUNNEL'
        if pr == 'udp' and sv == '10.0.2.30' and sp == 5004: return 'VOIP'
        if pr == 'udp' and sv == '10.0.2.30' and sp == 443: return 'QUICLIKE'
        if pr == 'tcp' and sv == '10.0.2.30' and sp == 80: return 'BULK'
    return None
def framing(u):
    k = u.key
    if k[0] == 'esp':
        sq = u.esp; inc = sum(1 for x, y in zip(sq, sq[1:]) if y == x + 1) / max(len(sq) - 1, 1)
        return 'ESP_SEQ_MONOTONIC' if len(sq) >= 5 and inc >= 0.9 else 'ESP_UNSTRUCTURED'
    if k[0] == 'udp':
        ds = [d for _, d in u.c2s]
        if not ds: return 'EMPTY'
        r = sum(wg_ok(d) for d in ds) / len(ds); ri = sum(ike_ok(d) for d in ds) / len(ds)
        return 'WIREGUARD_FRAMED' if len(ds) >= 3 and r >= 0.95 else ('IKEV2_FRAMED' if ri >= 0.95 else 'UNSTRUCTURED_UDP')
    s = rebuild(u.segs)
    if not s: return 'EMPTY'
    n, used = ovpn(s); m, usedt = tls(s)
    if n >= 3 and used / len(s) >= 0.9: return 'OPENVPN_FRAMED'
    if m >= 2 and usedt / len(s) >= 0.9: return 'TLS_FRAMED'
    if s[:4] == b'SSH-': return 'SSH_BANNER'
    if s[:4] in (b'GET ', b'POST', b'CONN', b'HEAD'): return 'HTTP_PLAINTEXT'
    return 'UNSTRUCTURED_TCP'
def heartbeat(u, min_gaps=2):
    ts = sorted(t for t, _ in u.c2s); iat = [b - a for a, b in zip(ts, ts[1:]) if b - a >= 1.0]
    if len(iat) < min_gaps: return None
    peak = collections.Counter(round(x * 2) / 2 for x in iat).most_common(1)[0][0]
    share = sum(1 for x in iat if abs(x - peak) <= 0.75) / len(iat)
    return (peak, share, len(iat)) if share >= 0.6 and 2 <= peak <= 120 else None
def entropy(b):
    if not b: return 0.0
    c = collections.Counter(b); n = len(b)
    return -sum(v / n * math.log2(v / n) for v in c.values())
def d_port(u): k = u.key; return k[0] == 'esp' or (k[0] == 'tcp' and k[4] == 1194) or (k[0] == 'udp' and k[4] in (1194, 51820))
def d_dur(u, T=5.0): return (u.t1 - u.t0) >= T
def d_frame(u): return framing(u) in ('OPENVPN_FRAMED', 'WIREGUARD_FRAMED', 'ESP_SEQ_MONOTONIC')
def d_heart(u): return heartbeat(u) is not None
def d_combo(u): return d_frame(u) or d_heart(u)
APPROVED = {'10.0.2.30'}
TUNNEL = ('OPENVPN', 'WIREGUARD', 'IPSEC', 'SSH', 'HTTP_PROXY')
def proxy_like(u):
    f = u.c2s[0][1] if u.c2s else b''
    return f.startswith(b'GET http') or f.startswith(b'CONNECT ')
def label(u):
    f = framing(u)
    if f == 'OPENVPN_FRAMED': return 'OPENVPN'
    if f == 'WIREGUARD_FRAMED': return 'WIREGUARD'
    if f == 'ESP_SEQ_MONOTONIC': return 'IPSEC'
    if f == 'SSH_BANNER': return 'SSH'
    if f == 'HTTP_PLAINTEXT' and proxy_like(u): return 'HTTP_PROXY'
    if f == 'TLS_FRAMED': return 'TLS'
    return 'UNKNOWN'
def d_policy(u): return label(u) in TUNNEL and u.key[3] not in APPROVED
DET = [('PORT', d_port), ('DUR>=5s', d_dur), ('FRAME', d_frame), ('HEART', d_heart), ('COMBO', d_combo), ('POLICY', d_policy)]
