#!/bin/bash
cd ~ || exit 1
sudo cp /var/log/dns_lab.log ~/dns_lab.log 2>/dev/null; sudo chown ubuntu:ubuntu ~/dns_lab.log 2>/dev/null
tar -cf ~/demo_data.tar pcaps/scene.pcap pcaps/evade.pcap remote_logs evidence dns_lab.log && echo "DEMO_SNAPSHOT: $(ls -l ~/demo_data.tar | awk '{print $5}') byte"
