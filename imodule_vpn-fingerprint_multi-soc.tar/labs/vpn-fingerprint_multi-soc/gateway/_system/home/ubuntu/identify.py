#!/usr/bin/env python3
import collections, csv, os, sys
sys.path.insert(0, os.path.expanduser('~/'))
from fplib import *
H = os.path.expanduser('~/'); S = H + 'suspects.csv'
if not os.path.exists(S): sys.exit('THIEU suspects.csv: chay Task 2 (python3 ~/triage.py) truoc')
pcap = os.path.expanduser(sys.argv[1]) if len(sys.argv) > 1 else H + 'pcaps/scene.pcap'
sus = {(r['client'], r['dst']) for r in csv.DictReader(open(S))}
rows = []
for k, u in sorted(units(pcap).items(), key=lambda kv: kv[1].t0):
    if (k[1], k[3]) not in sus: continue
    lb = label(u); hb = heartbeat(u); viol = lb in TUNNEL and k[3] not in APPROVED
    rows.append([k[1], k[3], k[4], k[0], lb, framing(u), ('%.1fs' % hb[0]) if hb else '-', round(u.t1 - u.t0, 1), 'VIOLATION' if viol else 'COMPLIANT'])
w = csv.writer(open(H + 'verdict.csv', 'w'), lineterminator='\n'); w.writerow(['client', 'dst', 'dport', 'proto', 'label', 'framing', 'heartbeat', 'dur_s', 'verdict']); w.writerows(rows)
agg = collections.OrderedDict()
for r in rows: agg.setdefault((r[0], r[1], r[4], r[8]), []).append(r)
lines = ['%-11s -> %-10s %-10s %-10s phien=%d nhip=%s' % (c, d, lb, v, len(x), x[0][6]) for (c, d, lb, v), x in agg.items()]
labs = {r[4] for r in rows if r[8] == 'VIOLATION'}
lines.append('IDENTIFY_OK' if {'OPENVPN', 'WIREGUARD', 'SSH', 'HTTP_PROXY'} <= labs else 'IDENTIFY_INCOMPLETE labels=' + ','.join(sorted(labs)))
open(H + 'identify.txt', 'w').write('\n'.join(lines) + '\n'); print('\n'.join(lines))
