#!/usr/bin/env python3
import importlib.util, os, sys
H = '/home/ubuntu/'
sys.path.insert(0, H)
from flowfeat import flows
if len(sys.argv) < 2 or '__' in open(H + 'classify.py').read():
    sys.exit('usage: heldout.py PCAP (can ~/classify.py da dien)')
spec = importlib.util.spec_from_file_location('cls', H + 'classify.py')
cls = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cls)
out = []
for key, f in sorted(flows(sys.argv[1]).items()):
    cl, sv, sp, pr = key
    if cl == '10.0.1.102' and sv == '10.0.2.10':
        lb = cls.classify(key, f)
        out.append('HELDOUT port=%d proto=%s label=%s DETECTOR_A=%s' % (sp, pr, lb, 'HIT' if sp in (1194, 51820, 1080, 3128) else 'MISS'))
        if lb == 'WIREGUARD' and sp not in (443, 51820, 1194, 1080, 3128):
            out.append('HELDOUT_WIREGUARD_OK')
open(H + 'heldout.txt', 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
