#!/usr/bin/env python3
import os
H = os.path.expanduser('~/')
G = [
    ('GIAMSAT', 'Task 1-2: Hien truong va giam sat', [
        ('scene', 'Bat hien truong (scene.pcap)', 'triage.txt', 'TRIAGE_OK'),
        ('netflow', 'NetFlow thay luong 443', 'nf_scene.txt', '10.0.2.10:443'),
        ('ghost', 'DNS ma / khoang trong DNS', 'suspects.csv', 'GHOST_DNS')]),
    ('DAUVANTAY', 'Task 3-4: Giai phau giao thuc va do dinh luong', [
        ('identify', 'Ket luan giao thuc (identify.py)', 'identify.txt', 'IDENTIFY_OK'),
        ('bulk', 'Danh gia nhieu phien (bulk_eval.py)', 'bulk_eval.txt', 'BULK_PASS'),
        ('featmatrix', 'Bang dac trung cheo giao thuc', 'featmatrix.txt', 'FEATMATRIX_OK')]),
    ('TRUYVET', 'Task 5: Truy vet nguoi dung xuyen NAT', [
        ('trace', 'Truy vet (trace.py)', 'trace.txt', 'TRACE_OK'),
        ('who', 'Xac dinh dung nguoi dung WireGuard', 'who.csv', 'tran_thi_b')]),
    ('CHUNGCU', 'Task 6: Forensic va chong gia mao', [
        ('forensic', 'Bang chung may tram khop ket luan (forensic.py)', 'forensic.txt', 'FORENSIC_OK'),
        ('custody', 'Chuoi luu giu SHA-256', 'evidence/chain_of_custody.csv', 'RESULT=VERIFIED'),
        ('gap', 'Phat hien xoa log cuc bo', 'tamper_c.txt', 'LOG_GAP_DETECTED')]),
    ('PHANUNG', 'Task 7-10: Phan ung, vong Red, bien ban', [
        ('block_port', 'Chan theo cong, co counter xac nhan', 'response.log', 'BLOCK_CONFIRMED mode=port'),
        ('guard', 'Hang rao khong chan dich duoc duyet', 'response.log', 'GUARD_SKIP'),
        ('evade', 'Ma tran ne tranh', 'evade_matrix.txt', 'EVADE_MATRIX_OK'),
        ('block_dst', 'Chan theo dich, xuyen qua doi cong', 'response.log', 'BLOCK_CONFIRMED mode=dst'),
        ('ticket', 'Nop bien ban (soc_gui.py)', 'forensics_ticket.json', 'TICKET_SUBMITTED')]),
]
def has(f, s):
    p = H + f
    return os.path.exists(p) and s in open(p, errors='ignore').read()
out = []; allok = True
for tag, title, items in G:
    res = [(i, has(i[2], i[3])) for i in items]; n = sum(r for _, r in res)
    out.append('== %s: %s ==' % (tag, title))
    for i, r in res: out.append('  [%s] %-10s %s' % ('OK   ' if r else 'THIEU', i[0], i[1]))
    ok = n == len(items); allok = allok and ok
    out.append('NHOM_%s=%s %d/%d' % (tag, 'OK' if ok else 'THIEU', n, len(items)))
if allok: out.append('LAB_C_COMPLETE')
open(H + 'grade_c.txt', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
