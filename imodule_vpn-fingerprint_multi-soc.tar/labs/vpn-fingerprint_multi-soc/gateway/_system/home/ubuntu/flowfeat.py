#!/usr/bin/env python3
import collections, math, os, sys
from scapy.all import rdpcap, IP, TCP, UDP

def entropy(b):
    if not b:
        return 0.0
    c = collections.Counter(b)
    n = len(b)
    return -sum(v / n * math.log2(v / n) for v in c.values())

def flows(path):
    F = {}
    for p in rdpcap(path):
        if not p.haslayer(IP):
            continue
        ip = p[IP]
        if ip.src.startswith('10.0.1.10') and ip.dst.startswith('10.0.2.'):
            up, cl, sv = True, ip.src, ip.dst
        elif ip.dst.startswith('10.0.1.10') and ip.src.startswith('10.0.2.'):
            up, cl, sv = False, ip.dst, ip.src
        else:
            continue
        raw = bytes(p)
        o = 14 + ip.ihl * 4
        end = 14 + ip.len
        if ip.proto == 6 and p.haslayer(TCP):
            l4, proto, hdr = p[TCP], 'tcp', p[TCP].dataofs * 4
        elif ip.proto == 17 and p.haslayer(UDP):
            l4, proto, hdr = p[UDP], 'udp', 8
        elif ip.proto == 50:
            l4, proto, hdr = None, 'esp', 0
        else:
            continue
        pay = raw[o + hdr:end]
        if l4 is None:
            cport = sport = 0
        else:
            cport, sport = (l4.sport, l4.dport) if up else (l4.dport, l4.sport)
        t = float(p.time)
        f = F.setdefault((cl, sv, sport, proto), {'up_p': 0, 'dn_p': 0, 'up_b': 0, 'dn_b': 0, 't0': t, 't1': t, 'conns': set(), 'first_up': None, 'sizes': []})
        f['t1'] = t
        f['conns'].add(cport)
        if up:
            f['up_p'] += 1
            f['up_b'] += len(pay)
            if pay and f['first_up'] is None:
                f['first_up'] = pay
            if pay and len(f['sizes']) < 6:
                f['sizes'].append(len(pay))
        else:
            f['dn_p'] += 1
            f['dn_b'] += len(pay)
    return F

def show(path):
    out = ['== %s ==' % os.path.basename(path)]
    for (cl, sv, sp, pr), f in sorted(flows(path).items()):
        fu = f['first_up'] or b''
        out.append('%s -> %s:%d %s conns=%d pk=%d/%d B=%d/%d ratio=%.2f dur=%.1fs first_len=%d ent=%.2f first4=%s sizes=%s' % (
            cl, sv, sp, pr, len(f['conns']), f['up_p'], f['dn_p'], f['up_b'], f['dn_b'],
            f['up_b'] / max(f['dn_b'], 1), f['t1'] - f['t0'], len(fu), entropy(fu), fu[:4].hex() or '-', f['sizes']))
    return '\n'.join(out)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit('usage: flowfeat.py PCAP [PCAP...]')
    for a in sys.argv[1:]:
        txt = show(a)
        print(txt)
        open(os.path.expanduser('~/features.txt'), 'a').write(txt + '\n')
