#!/usr/bin/env python3
import collections, importlib.util, os, sys
H = '/home/ubuntu/'
sys.path.insert(0, H)
from flowfeat import flows
if '__' in open(H + 'classify.py').read():
    print('CLASSIFIER_INCOMPLETE: dien not cac cho trong trong ~/classify.py')
    sys.exit(1)
spec = importlib.util.spec_from_file_location('cls', H + 'classify.py')
cls = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cls)
OK = set()
for l in open(H + 'approved_vpn.csv'):
    if l.strip() and not l.startswith('#'):
        OK.add(l.split(',')[0].strip())
E1, E2, E3, E4 = '10.0.1.101', '10.0.1.102', '10.0.1.103', '10.0.1.104'
VPS, CORP = '10.0.2.10', '10.0.2.30'
TRUTH = {
    (E4, VPS, 853, 'tcp'): ('DOT', 'COMPLIANT'),
    (E4, CORP, 22, 'tcp'): ('SSH', 'COMPLIANT'),
    (E4, CORP, 443, 'tcp'): ('HTTPS', 'COMPLIANT'),
    (E1, VPS, 443, 'tcp'): ('OPENVPN', 'VIOLATION'),
    (E2, VPS, 443, 'udp'): ('WIREGUARD', 'VIOLATION'),
    (E3, CORP, 0, 'esp'): ('IPSEC', 'COMPLIANT'),
    (E3, CORP, 500, 'udp'): ('IPSEC', 'COMPLIANT'),
    (E3, CORP, 4500, 'udp'): ('IPSEC', 'COMPLIANT'),
    (E4, VPS, 3128, 'tcp'): ('HTTP_PROXY', 'VIOLATION'),
    (E4, VPS, 22, 'tcp'): ('SSH', 'VIOLATION'),
}
PCAPS = ['1_benign', '2_ovpn', '3_wg', '4_ipsec', '5_squid', '6_sshd']
TUNNEL = {'OPENVPN', 'WIREGUARD', 'IPSEC', 'HTTP_PROXY', 'SSH'}
def verdict(label, sv):
    if label.startswith('UNKNOWN'):
        return 'VIOLATION'
    if label in TUNNEL and sv not in OK:
        return 'VIOLATION'
    return 'COMPLIANT'
missing = [p for p in PCAPS if not os.path.exists(H + 'pcaps/' + p + '.pcap')]
if missing:
    print('MISSING ' + ' '.join(missing))
    sys.exit(1)
M = {'A': [0, 0, 0, 0], 'B': [0, 0, 0, 0], 'C': [0, 0, 0, 0]}
conf = collections.Counter()
extra = []
for p in PCAPS:
    for key, f in flows(H + 'pcaps/' + p + '.pcap').items():
        if key not in TRUTH:
            extra.append('%s %s' % (p, key))
            continue
        tl, tv = TRUTH[key]
        sv, sport, pr = key[1], key[2], key[3]
        fu = f['first_up'] or b''
        label = cls.classify(key, f)
        conf[(tl, label)] += 1
        flags = {'A': sport in (1194, 51820, 1080, 3128),
                 'B': sport == 443 and (pr == 'udp' or fu[:2] != b'\x16\x03'),
                 'C': verdict(label, sv) == 'VIOLATION'}
        pos = (tv == 'VIOLATION')
        for d, fl in flags.items():
            i = 0 if (pos and fl) else (1 if pos else (2 if fl else 3))
            M[d][i] += 1
names = {'A': 'cong mac dinh 1194/51820/1080/3128', 'B': 'cong 443 nhung goi dau khong phai TLS', 'C': 'dau van tay noi dung + chinh sach dich den'}
out = ['Danh gia 3 bo do tren 6 mau (positive = VIOLATION):']
for d in 'ABC':
    tp, fn, fp, tn = M[d]
    out.append('Bo do %s (%s): TP=%d FN=%d FP=%d TN=%d' % (d, names[d], tp, fn, fp, tn))
out.append('Nhan giao thuc cua bo do C (that -> doan : so luong):')
for (t, l), n in sorted(conf.items()):
    out.append('  %s -> %s : %d' % (t, l, n))
if extra:
    out.append('Luong ngoai bang dap an (bo qua): ' + '; '.join(extra))
total = sum(conf.values())
right = sum(n for (t, l), n in conf.items() if t == l)
out.append('Do chinh xac nhan: %d/%d' % (right, total))
tp, fn, fp, tn = M['C']
if fn == 0 and fp == 0 and tp >= 4 and right == total:
    out.append('LAB_MULTISOC_PASS')
txt = '\n'.join(out) + '\n'
open(H + 'eval_c.txt', 'w').write(txt)
print(txt)
