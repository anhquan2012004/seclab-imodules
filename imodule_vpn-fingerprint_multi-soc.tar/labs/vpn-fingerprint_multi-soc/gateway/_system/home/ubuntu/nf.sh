#!/bin/bash
[ -f "$1" ] || { echo "usage: nf.sh PCAP [SO_DONG]"; exit 1; }
N=$(basename "$1" .pcap); D=$HOME/nf_$N; rm -rf "$D"; mkdir -p "$D"
nfcapd -D -l "$D" -p 9996 -P /tmp/nfcapd_$N.pid
sleep 1
softflowd -r "$1" -n 127.0.0.1:9996 -v 9 > /dev/null 2>&1
sleep 2
kill $(cat /tmp/nfcapd_$N.pid) 2>/dev/null
sleep 2
nfdump -R "$D" -o line | tee $HOME/nf_$N.txt | head -${2:-15}
