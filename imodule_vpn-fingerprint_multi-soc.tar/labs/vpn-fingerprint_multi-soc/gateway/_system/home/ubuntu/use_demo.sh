#!/bin/bash
[ -d ~/demo ] || { echo "Chua co ~/demo (xem huong dan dong goi du lieu demo)"; exit 1; }
mkdir -p ~/pcaps; cp -r ~/demo/pcaps/. ~/pcaps/; cp -r ~/demo/remote_logs ~/; cp -r ~/demo/evidence ~/; cp ~/demo/dns_lab.log ~/
echo DEMO_READY
