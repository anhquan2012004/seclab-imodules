#!/usr/bin/env python3
import collections, os, sys
from scapy.all import rdpcap, IP, TCP, UDP
if len(sys.argv) < 2: sys.exit('usage: timing.py PCAP [PCAP...]')
def analyze(path):
    F = collections.defaultdict(list)
    for p in rdpcap(path):
        if not p.haslayer(IP) or not p[IP].src.startswith('10.0.1.') or not p[IP].dst.startswith('10.0.2.'): continue
        ip = p[IP]
        if p.haslayer(TCP) and len(bytes(p[TCP].payload)) > 0: F[(ip.src, p[TCP].sport, ip.dst, p[TCP].dport, 'tcp')].append(float(p.time))
        elif p.haslayer(UDP) and len(bytes(p[UDP].payload)) > 0: F[(ip.src, p[UDP].sport, ip.dst, p[UDP].dport, 'udp')].append(float(p.time))
        elif ip.proto == 50: F[(ip.src, 0, ip.dst, 0, 'esp')].append(float(p.time))
    res = []
    for k, ts in sorted(F.items()):
        ts.sort(); iat = [b - a for a, b in zip(ts, ts[1:]) if b - a >= 1.0]
        if len(iat) < 4: res.append('%s:%d -> %s:%d/%s packets=%d  TIMING=TOO_SHORT (can >= 5 khoang nghi, hien co %d)' % (k + (len(ts), len(iat)))); continue
        peak = collections.Counter(round(x * 2) / 2 for x in iat).most_common(1)[0][0]
        share = sum(1 for x in iat if abs(x - peak) <= 0.75) / len(iat); mean = sum(iat) / len(iat)
        sd = (sum((x - mean) ** 2 for x in iat) / len(iat)) ** 0.5
        hb = share >= 0.6 and 2 <= peak <= 120
        res.append('%s:%d -> %s:%d/%s packets=%d idle_gaps=%d peak_period=%.1fs share=%.0f%% stdev=%.2fs  TIMING=%s' % (k + (len(ts), len(iat), peak, 100 * share, sd, 'HEARTBEAT_%ds' % round(peak) if hb else 'NO_HEARTBEAT')))
    return ['[%s] %s' % (os.path.basename(path), x) for x in res]
out = []
for path in sys.argv[1:]: out += analyze(path)
open(os.path.expanduser('~/timing.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
