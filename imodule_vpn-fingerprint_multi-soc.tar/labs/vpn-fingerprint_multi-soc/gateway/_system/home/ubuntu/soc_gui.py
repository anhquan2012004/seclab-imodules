#!/usr/bin/env python3
import glob, json, os, socket, sys, tkinter as tk
from tkinter import ttk
H = '/home/ubuntu/'
sys.path.insert(0, H)
from fplib import units, label, framing, APPROVED, TUNNEL
r = tk.Tk()
r.title('SOC Console - Dieu tra & Phan loai luong VPN')
nb = ttk.Notebook(r)
nb.pack(fill='both', expand=True)
f1 = tk.Frame(nb)
nb.add(f1, text='Phan loai luong (PCAP)')
cb = ttk.Combobox(f1, values=sorted(os.path.basename(p) for p in glob.glob(H + 'pcaps/*.pcap')), width=34)
cb.pack(pady=4)
cols = ('cl', 'dst', 'pr', 'lb', 'fr', 'vd')
tv = ttk.Treeview(f1, columns=cols, show='headings', height=12)
for c, t in zip(cols, ('May tram', 'Dich:Cong', 'Giao thuc', 'Nhan', 'Cau truc khung', 'Ket luan')):
    tv.heading(c, text=t)
    tv.column(c, width=125)
tv.tag_configure('V', background='#ffd0d0')
tv.tag_configure('C', background='#d8f5d8')
tv.pack(padx=6)
msg = tk.StringVar()
def run():
    cb['values'] = sorted(os.path.basename(p) for p in glob.glob(H + 'pcaps/*.pcap'))
    if not cb.get():
        msg.set('Chon 1 file PCAP trong danh sach')
        return
    tv.delete(*tv.get_children())
    for k, u in sorted(units(H + 'pcaps/' + cb.get()).items(), key=lambda kv: kv[1].t0):
        pr, cl, cp, sv, sp, spi = k
        lb = label(u); fr = framing(u)
        bad = (lb in TUNNEL and sv not in APPROVED)
        tv.insert('', 'end', values=(cl, '%s:%d' % (sv, sp), pr, lb, fr, 'VIOLATION' if bad else 'COMPLIANT'), tags=('V' if bad else 'C',))
    msg.set('Da phan tich xong: %s' % cb.get())
tk.Button(f1, text='Phan loai PCAP', command=run).pack(pady=4)
tk.Label(f1, textvariable=msg).pack()
f2 = tk.Frame(nb)
nb.add(f2, text='Nop bien ban su co')
for j, h in enumerate(('IP', 'Nguoi dung', 'Kenh tunnel/proxy toi dich KHONG duoc duyet (cach nhau dau phay)', 'Ket luan')):
    tk.Label(f2, text=h, font=('Arial', 9, 'bold')).grid(row=0, column=j, padx=4)
rows = []
for i, ip in enumerate(('10.0.1.101', '10.0.1.102', '10.0.1.103', '10.0.1.104'), 1):
    tk.Label(f2, text=ip).grid(row=i, column=0)
    u = tk.Entry(f2, width=16); u.grid(row=i, column=1)
    lb = tk.Entry(f2, width=34); lb.grid(row=i, column=2)
    v = tk.StringVar(value='VIOLATION')
    tk.OptionMenu(f2, v, 'VIOLATION', 'COMPLIANT').grid(row=i, column=3)
    rows.append((ip, u, lb, v))
res = tk.StringVar()
def send():
    data = [{'ip': ip, 'user': u.get().strip(), 'labels': lb.get().strip(), 'verdict': v.get()} for ip, u, lb, v in rows]
    try:
        s = socket.create_connection(('127.0.0.1', 5003), 5)
        s.sendall((json.dumps(data) + '\n').encode())
        s.shutdown(socket.SHUT_WR)
        res.set(s.makefile().read())
    except Exception as e:
        res.set('LOI: %s' % e)
tk.Button(f2, text='Nop bien ban', command=send).grid(row=5, column=0, columnspan=4, pady=6)
tk.Label(f2, textvariable=res, justify='left', wraplength=640).grid(row=6, column=0, columnspan=4)
r.mainloop()
