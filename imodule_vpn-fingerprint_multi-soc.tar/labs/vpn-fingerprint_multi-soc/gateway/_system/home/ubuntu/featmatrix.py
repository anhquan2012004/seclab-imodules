#!/usr/bin/env python3
import collections, csv, os, statistics as st, sys
sys.path.insert(0, os.path.expanduser('~/'))
from fplib import *
if len(sys.argv) < 2: sys.exit('usage: featmatrix.py PCAP')
U = units(sys.argv[1]); G = collections.defaultdict(list)
for k, u in U.items():
    c = truth(k)
    if c: G[c].append(u)
med = lambda x: st.median(x) if x else 0
rows = []
for c in sorted(G):
    us = G[c]; fl = []; ml = []; sd = []; en = []; ra = []; hb = []; fr = collections.Counter(); pk = []
    for u in us:
        sizes = [len(d) for _, d in u.c2s]; pk.append(len(sizes))
        if sizes: fl.append(sizes[0]); ml.append(sum(sizes) / len(sizes)); sd.append(st.pstdev(sizes) if len(sizes) > 1 else 0)
        es = [entropy(d[:256]) for _, d in u.c2s if len(d) >= 32]
        if es: en.append(sum(es) / len(es))
        cb = sum(sizes)
        if u.s2c_bytes: ra.append(cb / u.s2c_bytes)
        h = heartbeat(u)
        if h: hb.append(h[0])
        fr[framing(u)] += 1
    rows.append([c, len(us), round(med([u.t1 - u.t0 for u in us]), 1), int(med(pk)), int(med(fl)), round(med(ml), 0), round(med(sd), 0), round(med(en), 2), (round(med(ra), 2) if ra else '-'), ('%ss' % med(hb) if hb else '-'), fr.most_common(1)[0][0]])
H = ['lop', 'so_phien', 'thoi_gian_s', 'goi_len', 'goi_dau_B', 'goi_tb_B', 'do_lech_B', 'entropy', 'ti_le_len/xuong', 'nhip', 'khung']
w = [max(len(str(x)) for x in [H[i]] + [r[i] for r in rows]) for i in range(len(H))]
out = ['  '.join(str(x).ljust(w[i]) for i, x in enumerate(H))] + ['  '.join(str(x).ljust(w[i]) for i, x in enumerate(r)) for r in rows]
if len(rows) >= 8: out.append('FEATMATRIX_OK (%d lop)' % len(rows))
open(os.path.expanduser('~/featmatrix.txt'), 'w').write('\n'.join(out) + '\n')
csv.writer(open(os.path.expanduser('~/featmatrix.csv'), 'w'), lineterminator='\n').writerows([H] + rows); print('\n'.join(out))
