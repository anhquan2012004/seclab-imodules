#!/usr/bin/env python3
import csv, os, sys
H = os.path.expanduser('~/'); W = H + 'who.csv'
if not os.path.exists(W): sys.exit('THIEU who.csv: chay Task 5 (python3 ~/trace.py) truoc')
HOST = {'10.0.1.101': 'emp-1', '10.0.1.102': 'emp-2', '10.0.1.103': 'emp-3', '10.0.1.104': 'emp-4'}
ART = {'OPENVPN': ('ps.txt', 'openvpn'), 'WIREGUARD': ('wg.txt', 'endpoint: 10.0.2.10'), 'SSH': ('ps.txt', 'ssh -f -N -D')}
def read(p):
    try: return open(p, errors='ignore').read()
    except OSError: return ''
cust = read(H + 'evidence/chain_of_custody.csv'); out = []; ok = True
for r in csv.DictReader(open(W)):
    h = HOST.get(r['ip'], '?'); verified = ('ev_%s.tar' % h in cust) and any(('ev_%s.tar' % h in l and 'RESULT=VERIFIED' in l) for l in cust.splitlines())
    for lb in r['labels'].split('|'):
        if lb in ART: f, s = ART[lb]; art = s in read(H + 'evidence/ev_%s/%s' % (h, f))
        elif lb == 'HTTP_PROXY': art = int(r['squid_hits']) > 0
        else: art = False
        ok = ok and art and verified
        out.append('host=%s label=%s bang_chung=%s chuoi_luu_giu=%s' % (h, lb, 'KHOP' if art else 'THIEU', 'VERIFIED' if verified else 'THIEU'))
gap = 'LOG_GAP_DETECTED' in read(H + 'tamper_c.txt')
out.append('xoa_log_cuc_bo=%s' % ('PHAT_HIEN' if gap else 'CHUA_PHAT_HIEN'))
out.append('FORENSIC_OK' if ok and gap and out else 'FORENSIC_INCOMPLETE')
open(H + 'forensic.txt', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
