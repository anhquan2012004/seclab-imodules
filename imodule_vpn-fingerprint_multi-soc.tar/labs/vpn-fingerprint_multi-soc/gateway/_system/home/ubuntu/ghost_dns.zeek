@load base/protocols/dns
module GhostDNS;
export {
    redef enum Log::ID += { LOG };
    type Info: record {
        client: addr &log;
        name: string &log;
        resolved: addr &log;
        first_seen: time &log;
    };
}
global qname: table[addr, addr] of string;
global qtime: table[addr, addr] of time;
global contacted: set[addr, addr];
event zeek_init()
    {
    Log::create_stream(GhostDNS::LOG, [$columns=Info, $path="dns_ghost"]);
    }
event dns_A_reply(c: connection, msg: dns_msg, ans: dns_answer, a: addr)
    {
    local cl = c$id$orig_h;
    if ( [cl, a] !in qname )
        {
        qname[cl, a] = ans$query;
        qtime[cl, a] = network_time();
        }
    }
event connection_state_remove(c: connection)
    {
    add contacted[c$id$orig_h, c$id$resp_h];
    }
event zeek_done()
    {
    for ( [cl, a] in qname )
        if ( [cl, a] !in contacted )
            Log::write(GhostDNS::LOG, Info($client=cl, $name=qname[cl, a], $resolved=a, $first_seen=qtime[cl, a]));
    }
