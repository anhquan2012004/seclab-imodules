#!/usr/bin/env python3
import collections, os, sys
if len(sys.argv) < 2: sys.exit('usage: dns_gap.py THU_MUC_ZEEK_LOG   (vi du: dns_gap.py ~/zl_dns)')
D = sys.argv[1]; MIN_DUR = 5.0; WATCH = ('weibo',)
def rows(path):
    names = None
    for l in open(path, errors='ignore'):
        l = l.rstrip('\n')
        if l.startswith('#fields'): names = l.split('\t')[1:]; continue
        if not l or l.startswith('#') or names is None: continue
        yield dict(zip(names, l.split('\t')))
fl = lambda x: 0.0 if x in ('-', '(empty)', '') else float(x)
res = collections.defaultdict(dict); asked = collections.defaultdict(list)
for r in rows(D + '/dns.log'):
    if r.get('rcode_name') not in ('NOERROR', '-') or r.get('qtype_name') != 'A': continue
    for a in r.get('answers', '-').split(','):
        if a.count('.') == 3 and a.replace('.', '').isdigit(): res[r['id.orig_h']].setdefault(a, (fl(r['ts']), r['query']))
    asked[r['id.orig_h']].append(r['query'])
conn = collections.defaultdict(list); out = []; sus = {}
for r in rows(D + '/conn.log'):
    if not r['id.orig_h'].startswith('10.0.1.') or not r['id.resp_h'].startswith('10.0.2.'): continue
    dur = fl(r.get('duration', '-')); key = (r['id.orig_h'], r['id.resp_h'], r['id.resp_p'], r['proto'])
    d = res[r['id.orig_h']].get(r['id.resp_h'])
    conn[r['id.orig_h']].append(r['id.resp_h'])
    if dur >= MIN_DUR or r['proto'] in ('unknown_transport', 'udp') and r['id.resp_p'] in ('500', '4500'):
        if d and d[0] <= fl(r['ts']): out.append('%s -> %s:%s/%s duration=%.1fs  DNS=BACKED (%s)' % (key[0], key[1], key[2], key[3], dur, d[1]))
        else: out.append('%s -> %s:%s/%s duration=%.1fs  DNS=NONE'  % (key[0], key[1], key[2], key[3], dur)); sus[key[0]] = sus.get(key[0], 0) + 1
for c, rs in sorted(res.items()):
    ghost = [(a, n) for a, (t, n) in rs.items() if a not in conn[c]]
    for a, n in ghost:
        w = any(x in n for x in WATCH)
        out.append('%s hoi ten %s -> %s nhung KHONG co luong truc tiep toi %s  GHOST_DNS%s' % (c, n, a, a, '  WATCHLIST' if w else ''))
        if sus.get(c): out.append('TUNNEL_SUSPECT client=%s ghost=%s long_flows_without_dns=%d' % (c, a, sus[c]))
open(os.path.expanduser('~/dns_gap.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
