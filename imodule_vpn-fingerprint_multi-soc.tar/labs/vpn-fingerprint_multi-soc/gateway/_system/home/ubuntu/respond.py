#!/usr/bin/env python3
# usage: respond.py [--mode port|dst] [--apply] [--ttl GIAY] | --verify [--mode ...] | --clear
import csv, os, re, subprocess, sys
H = os.path.expanduser('~/'); A = sys.argv[1:]; APPROVED = {'10.0.2.30'}; LOG = H + 'response.log'
mode = A[A.index('--mode') + 1] if '--mode' in A else 'port'; ttl = int(A[A.index('--ttl') + 1]) if '--ttl' in A else 90
TUN = ('OPENVPN', 'WIREGUARD', 'IPSEC', 'SSH', 'HTTP_PROXY')
sh = lambda c: subprocess.run(['sudo'] + c, capture_output=True, text=True)
def log(s): open(LOG, 'a').write(s + '\n'); print(s)
for f, t in (('verdict.csv', 3), ('who.csv', 5)):
    if not os.path.exists(H + f): sys.exit('THIEU %s: chay Task %d truoc' % (f, t))
def plan(quiet=False):
    out = []; seen = set()
    for r in csv.DictReader(open(H + 'verdict.csv')):
        if r['label'] not in TUN: continue
        if r['dst'] in APPROVED:
            if not quiet and (r['client'], r['dst']) not in seen: log('GUARD_SKIP client=%s dst=%s nhan=%s (dich duoc duyet)' % (r['client'], r['dst'], r['label']))
            seen.add((r['client'], r['dst'])); continue
        k = (r['client'], r['dst']) if mode == 'dst' else (r['client'], r['dst'], r['proto'], r['dport'])
        if k not in seen: seen.add(k); out.append(k)
    return out
def spec(k): return ['-s', k[0], '-d', k[1]] + (['-p', k[2], '--dport', k[3]] if len(k) == 4 else []) + ['-j', 'DROP']
if '--clear' in A:
    for m in ('port', 'dst'):
        mode = m
        for k in plan(True): sh(['iptables', '-D', 'FORWARD'] + spec(k))
    log('CLEARED'); sys.exit(0)
R = plan('--verify' in A); apply = '--apply' in A
if '--verify' in A:
    tab = sh(['iptables', '-L', 'FORWARD', '-v', '-n', '-x']).stdout; hit = 0
    for k in R:
        pk = 0
        for l in tab.splitlines():
            m = re.match(r'^\s*(\d+)\s+\d+\s+DROP\s+(\S+)\s+--\s+\S+\s+\S+\s+(\S+)\s+(\S+)\s*(.*)$', l)
            if m and m.group(3) == k[0] and m.group(4) == k[1] and (len(k) == 2 or ('dpt:%s' % k[3]) in m.group(5)): pk += int(m.group(1))
        log('%s mode=%s client=%s dst=%s pkts=%d' % ('BLOCK_CONFIRMED' if pk else 'NO_HITS', mode, k[0], k[1], pk)); hit += bool(pk)
    sys.exit(0 if hit else 1)
for k in R:
    cmd = ['iptables', '-I', 'FORWARD', '1'] + spec(k)
    if not apply: print('DRY-RUN: iptables -I FORWARD 1 ' + ' '.join(spec(k))); continue
    sh(cmd); subprocess.Popen(['sudo', 'sh', '-c', 'sleep %d; iptables -D FORWARD %s' % (ttl, ' '.join(spec(k)))], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    log('APPLIED mode=%s client=%s dst=%s het_han_sau=%ds' % (mode, k[0], k[1], ttl))
if not apply: log('DRYRUN mode=%s rules=%d (them --apply de ap dung)' % (mode, len(R)))
