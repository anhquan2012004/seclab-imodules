#!/usr/bin/env python3
import collections, os, sys
sys.path.insert(0, os.path.expanduser('~/'))
from fplib import *
if len(sys.argv) < 2: sys.exit('usage: evade_matrix.py scene=~/pcaps/scene.pcap evade=~/pcaps/evade.pcap')
MODES = ['portswap', 'jitter', 'nested', 'nested_jitter']
cols = collections.OrderedDict(); warn = []
for name, path in [a.split('=', 1) for a in sys.argv[1:]]:
    U = units(os.path.expanduser(path)); L = {k: truth(k) for k in U}
    if name == 'evade':
        by = collections.defaultdict(list)
        for k, u in sorted(U.items(), key=lambda kv: kv[1].t0):
            if L[k] in VPN and (u.t1 - u.t0) >= 3.0 and len(u.c2s) >= 2:
                by[L[k]].append(u)
        for c, us in by.items():
            if len(us) > len(MODES): us = us[-len(MODES):]
            if len(us) != len(MODES): warn.append('CANH BAO: %s co %d phien trong evade.pcap, ky vong %d' % (c, len(us), len(MODES)))
            for m, u in zip(MODES, us): cols.setdefault(m, []).append((c, u))
    else:
        for k, u in U.items():
            if L[k] in VPN: cols.setdefault(name, []).append((L[k], u))
out = warn + ['Ma tran ne tranh: recall cua tung bo do (OPENVPN/WIREGUARD/IPSEC), 1.00 = bat het, 0.00 = bo sot het',
              'POLICY: co bao vi pham khi nhan dang la tunnel toi dich KHONG duoc duyet (IPSEC cong ty duoc duyet nen cot IPSEC cua no cung co y de trong)']
out.append('%-9s ' % 'bo do' + ' '.join('%-17s' % n for n in cols))
for dn, fn in DET:
    cells = []
    for n, us in cols.items():
        cell = []
        for c in VPN:
            ks = [u for cc, u in us if cc == c]
            cell.append('%.2f' % (sum(1 for u in ks if fn(u)) / len(ks)) if ks else ' -- ')
        cells.append('/'.join(cell))
    out.append('%-9s ' % dn + ' '.join('%-17s' % c for c in cells))
if len(cols) >= 5 and not warn: out.append('EVADE_MATRIX_OK (%d cot)' % len(cols))
open(os.path.expanduser('~/evade_matrix.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
