#!/usr/bin/env python3
import collections, csv, os, subprocess, sys
H = os.path.expanduser('~/')
pcap = os.path.expanduser(sys.argv[1]) if len(sys.argv) > 1 else H + 'pcaps/scene.pcap'
Z = H + 'zl_scene'
if not os.path.exists(Z + '/conn.log'):
    if not os.path.exists(pcap): sys.exit('THIEU %s: chay Task 1 (cap.sh scene) truoc' % pcap)
    subprocess.run(['zeek-run.sh', pcap, Z])
if os.path.exists(H + 'nf.sh') and os.path.exists(pcap):
    r = subprocess.run([H + 'nf.sh', pcap, '200'], capture_output=True, text=True); open(H + 'nf_scene.txt', 'w').write(r.stdout)
def rows(path):
    names = None
    for l in open(path, errors='ignore'):
        l = l.rstrip('\n')
        if l.startswith('#fields'): names = l.split('\t')[1:]; continue
        if not l or l.startswith('#') or names is None: continue
        yield dict(zip(names, l.split('\t')))
fl = lambda x: 0.0 if x in ('-', '(empty)', '') else float(x)
res = collections.defaultdict(dict)
if os.path.exists(Z + '/dns.log'):
    for r in rows(Z + '/dns.log'):
        if r.get('qtype_name') != 'A' or r.get('rcode_name') not in ('NOERROR', '-'): continue
        for a in r.get('answers', '-').split(','):
            if a.count('.') == 3 and a.replace('.', '').isdigit(): res[r['id.orig_h']].setdefault(a, (fl(r['ts']), r['query']))
agg = collections.OrderedDict(); contacted = collections.defaultdict(set)
for r in rows(Z + '/conn.log'):
    c, d = r['id.orig_h'], r['id.resp_h']
    if not (c.startswith('10.0.1.') and d.startswith('10.0.2.')): continue
    contacted[c].add(d); dur = fl(r.get('duration', '-')); why = []
    if dur >= 5 and r.get('service', '-') in ('-', '(empty)') and r['proto'] in ('tcp', 'udp', 'unknown_transport'): why.append('ZEEK_BLIND')
    h = res[c].get(d)
    if not (h and h[0] <= fl(r['ts'])): why.append('NO_DNS')
    if why:
        a = agg.setdefault((c, d, r['id.resp_p'], r['proto']), {'n': 0, 'dur': 0.0, 'why': set()}); a['n'] += 1; a['dur'] = max(a['dur'], dur); a['why'].update(why)
ghost = {c: [n for ip, (t, n) in rs.items() if ip not in contacted[c]] for c, rs in res.items()}
out = [(c, d, p, pr, a['n'], round(a['dur'], 1), ';'.join(sorted(a['why']) + ['GHOST_DNS:' + n for n in ghost.get(c, [])])) for (c, d, p, pr), a in agg.items()]
w = csv.writer(open(H + 'suspects.csv', 'w'), lineterminator='\n'); w.writerow(['client', 'dst', 'dport', 'proto', 'flows', 'max_dur_s', 'reasons']); w.writerows(out)
lines = ['%-11s -> %-10s %5s/%-17s n=%d dur=%5.1fs  %s' % (o[0], o[1], o[2], o[3], o[4], o[5], o[6]) for o in out]
nb = sum('ZEEK_BLIND' in o[6] for o in out); ng = sum('GHOST_DNS' in o[6] for o in out)
lines.append('TRIAGE_OK suspects=%d zeek_blind=%d ghost_dns=%d' % (len(out), nb, ng) if nb and ng and len(out) >= 4 else 'TRIAGE_INCOMPLETE suspects=%d zeek_blind=%d ghost_dns=%d' % (len(out), nb, ng))
open(H + 'triage.txt', 'w').write('\n'.join(lines) + '\n'); print('\n'.join(lines))
