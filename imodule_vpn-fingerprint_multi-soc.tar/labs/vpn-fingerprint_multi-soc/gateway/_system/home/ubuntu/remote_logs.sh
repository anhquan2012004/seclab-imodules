#!/bin/bash
mkdir -p ~/remote_logs
sudo cp /var/log/remote/*.log ~/remote_logs/ 2>/dev/null
sudo chown -R ubuntu:ubuntu ~/remote_logs
ls -l ~/remote_logs
