#!/usr/bin/env python3
import glob, importlib.util, os, sqlite3, sys
H = '/home/ubuntu/'
sys.path.insert(0, H)
from scapy.all import rdpcap, Ether, IP
from flowfeat import flows
if '__' in open(H + 'classify.py').read():
    sys.exit('CLASSIFIER_INCOMPLETE: dien ~/classify.py truoc')
spec = importlib.util.spec_from_file_location('cls', H + 'classify.py')
cls = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cls)
OK = {l.split(',')[0].strip() for l in open(H + 'approved_vpn.csv') if l.strip() and not l.startswith('#')}
TUN = {'OPENVPN', 'WIREGUARD', 'IPSEC', 'HTTP_PROXY', 'SSH'}
db = sqlite3.connect(H + 'idm.db')
rows = set()
for pc in sys.argv[1:] or sorted(glob.glob(H + 'pcaps/[1-6]_*.pcap')):
    mac = {}
    for p in rdpcap(pc):
        if p.haslayer(IP) and p.haslayer(Ether) and p[IP].src.startswith('10.0.1.10'):
            mac.setdefault(p[IP].src, p[Ether].src)
    for key, f in flows(pc).items():
        cl, sv, sp, pr = key
        label = cls.classify(key, f)
        bad = label.startswith('UNKNOWN') or (label in TUN and sv not in OK)
        u = db.execute('select user from devices where mac=?', (mac.get(cl, ''),)).fetchone() or ('?',)
        rows.add('USER=%s IP=%s MAC=%s LABEL=%s DEST=%s:%d VERDICT=%s' % (u[0], cl, mac.get(cl, '?'), label, sv, sp, 'VIOLATION' if bad else 'COMPLIANT'))
txt = '\n'.join(sorted(rows)) + '\n'
open(H + 'peers_c.txt', 'w').write(txt)
print(txt)
