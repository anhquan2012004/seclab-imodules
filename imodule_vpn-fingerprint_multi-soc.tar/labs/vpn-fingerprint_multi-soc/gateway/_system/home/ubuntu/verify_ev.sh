#!/bin/bash
cd ~/evidence || exit 1
echo "item,sha256_client,sha256_gateway,result,verified_at_utc" > chain_of_custody.csv
for f in ev_*.tar.sha256; do
  t=${f%.sha256}; S=$(cut -d' ' -f1 $f); R=$(sha256sum $t | cut -d' ' -f1)
  [ "$S" = "$R" ] && M=VERIFIED || M=TAMPERED
  echo "$t,$S,$R,RESULT=$M,$(date -u +%FT%TZ)" >> chain_of_custody.csv
  tar -xf $t
done
cat chain_of_custody.csv
