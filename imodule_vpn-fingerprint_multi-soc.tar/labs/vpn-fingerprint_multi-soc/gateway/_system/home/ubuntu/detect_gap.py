#!/usr/bin/env python3
import os
H = os.path.expanduser('~/')
def marks(p):
    return [l.strip() for l in open(p, errors='ignore') if 'shadowtun' in l] if os.path.exists(p) else []
rem = marks(H + 'remote_logs/emp-4.log')
loc = marks(H + 'evidence/ev_emp-4/syslog')
out = ['REMOTE_MARKERS=%d LOCAL_MARKERS=%d' % (len(rem), len(loc))]
if rem and not loc:
    out.append('LOG_GAP_DETECTED: log tap trung con %d dong shadowtun, log cuc bo tren emp-4 khong con dong nao -> log cuc bo da bi xoa' % len(rem))
    out.append('  ' + rem[0][:140])
open(H + 'tamper_c.txt', 'w').write('\n'.join(out) + '\n')
print('\n'.join(out))
