#!/usr/bin/env python3
# Bo phan loai luong theo noi dung goi dau tien, khong dua vao cong.
# Dien not cac cho trong, moi cho mot gia tri, dua tren so do trong features.txt.
WG_FIRST_LEN = __
WG_FIRST4 = '__'
OVPN_OPCODE = 0x__
IKE_PORT_A = __
IKE_PORT_B = __
DOT_PORT = __

def classify(key, f):
    cl, sv, sp, pr = key
    fu = f['first_up'] or b''
    if pr == 'esp':
        return 'IPSEC'
    if pr == 'udp':
        if sp in (IKE_PORT_A, IKE_PORT_B):
            return 'IPSEC'
        if len(fu) == WG_FIRST_LEN and fu[:4].hex() == WG_FIRST4:
            return 'WIREGUARD'
        return 'UNKNOWN_UDP'
    if len(fu) >= 3 and int.from_bytes(fu[:2], 'big') == len(fu) - 2 and fu[2] == OVPN_OPCODE:
        return 'OPENVPN'
    if fu[:2] == b'\x16\x03':
        return 'DOT' if sp == DOT_PORT else 'HTTPS'
    if fu[:4] == b'SSH-':
        return 'SSH'
    if fu.startswith(b'GET http') or fu.startswith(b'CONNECT '):
        return 'HTTP_PROXY'
    return 'UNKNOWN_TCP'
