#!/usr/bin/env python3
import os, socket, sys
n = int(sys.argv[1]) if len(sys.argv) > 1 else 2
os.makedirs('/home/ubuntu/evidence', exist_ok=True)
s = socket.socket()
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('0.0.0.0', 9000))
s.listen(5)
print('Dang cho %d file (cong 9000)...' % n)
for _ in range(n):
    c, a = s.accept()
    f = c.makefile('rb')
    name = os.path.basename(f.readline().decode().strip())
    open('/home/ubuntu/evidence/' + name, 'wb').write(f.read())
    print('RECEIVED', name, 'from', a[0])
