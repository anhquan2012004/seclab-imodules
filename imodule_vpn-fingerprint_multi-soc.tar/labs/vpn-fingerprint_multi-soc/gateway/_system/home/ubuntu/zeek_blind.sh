#!/bin/bash
[ -f "$1" ] || { echo "usage: zeek_blind.sh PCAP"; exit 1; }
N=$(basename "$1" .pcap)
zeek-run.sh "$1" $HOME/zl_$N | grep -q ZEEK_OK || { echo ZEEK_FAILED; exit 1; }
echo "== $N: luong (cong, giao thuc, service Zeek) =="
cat $HOME/zl_$N/conn.log | zeek-cut id.orig_h id.resp_h id.resp_p proto service orig_bytes resp_bytes | grep -v -E "^(fe80|ff0|10.0.1.254)" | head -12
echo "== ssl.log =="
cat $HOME/zl_$N/ssl.log 2>/dev/null | zeek-cut id.orig_h id.resp_h server_name version | head -5
U=$(cat $HOME/zl_$N/conn.log | zeek-cut id.resp_h id.resp_p proto service | awk -F'\t' '$1 ~ /^10\.0\.2\./ && $2==443 && $4=="-"{n++} END{print n+0}')
echo "PCAP=$N ZEEK_UNKNOWN_443=$U" | tee -a $HOME/zeek_blind.txt
