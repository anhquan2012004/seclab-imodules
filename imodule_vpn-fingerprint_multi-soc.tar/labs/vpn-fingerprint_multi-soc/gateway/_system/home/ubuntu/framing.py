#!/usr/bin/env python3
import collections, os, sys
from scapy.all import rdpcap, IP, TCP, UDP
if len(sys.argv) < 2: sys.exit('usage: framing.py PCAP [PCAP...]')
def rebuild(segs):
    out = b''; nxt = None
    for sq, d in sorted(set(segs)):
        if nxt is None: nxt = sq
        if sq > nxt: break
        if sq + len(d) <= nxt: continue
        out += d[nxt - sq:]; nxt = sq + len(d)
    return out
def ovpn(b):
    i = n = 0
    while i + 3 <= len(b):
        L = int.from_bytes(b[i:i + 2], 'big'); op = b[i + 2] >> 3
        if not (1 <= L <= 1700 and 1 <= op <= 11): break
        n += 1; i = min(i + 2 + L, len(b))
    return n, i
def tls(b):
    i = n = 0
    while i + 5 <= len(b):
        L = int.from_bytes(b[i + 3:i + 5], 'big')
        if not (0x14 <= b[i] <= 0x18 and b[i + 1] == 3 and b[i + 2] <= 4 and L <= 16645): break
        n += 1; i = min(i + 5 + L, len(b))
    return n, i
def wg_ok(d):
    if len(d) < 32 or d[1:4] != b'\0\0\0': return False
    t = d[0]
    return (t == 1 and len(d) == 148) or (t == 2 and len(d) == 92) or (t == 3 and len(d) == 64) or (t == 4 and (len(d) - 32) % 16 == 0)
def ike_ok(d):
    if d[:4] == b'\0\0\0\0': d = d[4:]
    return len(d) >= 28 and d[17] == 0x20 and d[18] in (34, 35, 36, 37) and int.from_bytes(d[24:28], 'big') == len(d)
def analyze(path):
    tcp = collections.defaultdict(list); udp = collections.defaultdict(list); esp = collections.defaultdict(list)
    for p in rdpcap(path):
        if not p.haslayer(IP) or not p[IP].src.startswith('10.0.1.'): continue
        ip = p[IP]
        if ip.proto == 50 and ip.dst.startswith('10.0.2.'): b = bytes(ip.payload); esp[(ip.src, ip.dst)].append((int.from_bytes(b[:4], 'big'), int.from_bytes(b[4:8], 'big')))
        elif p.haslayer(TCP) and ip.dst.startswith('10.0.2.'):
            b = bytes(p[TCP].payload)
            if b: tcp[(ip.src, p[TCP].sport, ip.dst, p[TCP].dport)].append((p[TCP].seq, b))
        elif p.haslayer(UDP) and ip.dst.startswith('10.0.2.'):
            b = bytes(p[UDP].payload)
            if b: udp[(ip.src, p[UDP].sport, ip.dst, p[UDP].dport)].append(b)
    res = []
    for k, segs in tcp.items():
        s = rebuild(segs); n, used = ovpn(s); m, usedt = tls(s); r = used / len(s) if s else 0; rt = usedt / len(s) if s else 0
        if n >= 3 and r >= 0.9: f = 'OPENVPN_FRAMED'
        elif m >= 2 and rt >= 0.9: f = 'TLS_FRAMED'
        elif s[:4] == b'SSH-': f = 'SSH_BANNER'
        elif s[:4] in (b'GET ', b'POST', b'CONN', b'HEAD'): f = 'HTTP_PLAINTEXT'
        else: f = 'UNSTRUCTURED_TCP'
        res.append('%s:%d -> %s:%d/tcp bytes=%d ovpn_frames=%d(%.0f%%) tls_records=%d(%.0f%%)  FRAMING=%s' % (k[0], k[1], k[2], k[3], len(s), n, 100 * r, m, 100 * rt, f))
    for k, ds in udp.items():
        w = sum(wg_ok(d) for d in ds); ik = sum(ike_ok(d) for d in ds); r = w / len(ds); ri = ik / len(ds)
        f = 'WIREGUARD_FRAMED' if len(ds) >= 3 and r >= 0.95 else ('IKEV2_FRAMED' if ri >= 0.95 else 'UNSTRUCTURED_UDP')
        res.append('%s:%d -> %s:%d/udp datagrams=%d wg_conform=%.0f%% ike_conform=%.0f%%  FRAMING=%s' % (k[0], k[1], k[2], k[3], len(ds), 100 * r, 100 * ri, f))
    for k, L in esp.items():
        spis = {a for a, _ in L}; sq = [b for _, b in L]; inc = sum(1 for x, y in zip(sq, sq[1:]) if y == x + 1) / max(len(sq) - 1, 1)
        f = 'ESP_SEQ_MONOTONIC' if len(spis) <= 2 and len(sq) >= 5 and inc >= 0.9 else 'ESP_UNSTRUCTURED'
        res.append('%s -> %s/esp packets=%d spi_so=%d seq_tang_dan=%.0f%%  FRAMING=%s' % (k[0], k[1], len(sq), len(spis), 100 * inc, f))
    return ['[%s] %s' % (os.path.basename(path), x) for x in sorted(res)]
out = []
for path in sys.argv[1:]: out += analyze(path)
open(os.path.expanduser('~/framing.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
