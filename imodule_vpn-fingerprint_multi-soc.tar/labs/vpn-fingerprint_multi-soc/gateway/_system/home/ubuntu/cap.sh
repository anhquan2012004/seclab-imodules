#!/bin/bash
[ -n "$2" ] || { echo "usage: cap.sh TEN GIAY [LOC]"; exit 1; }
mkdir -p ~/pcaps
IN=$(ip -o -4 addr show | awk '$4 ~ /^10\.0\.1\.1\//{print $2}')
echo "Bat goi $2 giay tren $IN -> ~/pcaps/$1.pcap"
sudo timeout -s INT $2 tcpdump -i $IN -nn -U -w - ${3:+"$3"} > ~/pcaps/$1.pcap 2>/dev/null
echo "Xong: $(tcpdump -nn -r ~/pcaps/$1.pcap 2>/dev/null | wc -l) goi"
