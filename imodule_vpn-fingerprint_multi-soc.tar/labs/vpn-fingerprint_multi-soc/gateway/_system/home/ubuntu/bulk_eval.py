#!/usr/bin/env python3
import collections, math, os, sys
sys.path.insert(0, os.path.expanduser('~/'))
from fplib import *
if len(sys.argv) < 2: sys.exit('usage: bulk_eval.py PCAP')
def wilson(k, n, z=1.96):
    if n == 0: return (0.0, 0.0)
    p = k / n; d = 1 + z * z / n; c = p + z * z / (2 * n); a = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((c - a) / d, (c + a) / d)
U = units(sys.argv[1]); L = {k: truth(k) for k in U}; L = {k: v for k, v in L.items() if v}
cnt = collections.Counter(L.values())
out = ['== So don vi (moi phien = mot luong) theo lop ==', '  ' + '  '.join('%s=%d' % (c, cnt[c]) for c in sorted(cnt))]
def conf(fn):
    tp = fp = fn_ = tn = 0
    for k, c in L.items():
        pos = c in VPN; hit = fn(U[k])
        if pos and hit: tp += 1
        elif pos: fn_ += 1
        elif hit: fp += 1
        else: tn += 1
    return tp, fp, fn_, tn
def prf(tp, fp, fn_):
    p = tp / (tp + fp) if tp + fp else 0.0; r = tp / (tp + fn_) if tp + fn_ else 0.0
    return p, r, (2 * p * r / (p + r) if p + r else 0.0)
out.append('== Bo do (positive = giao thuc VPN: OPENVPN, WIREGUARD, IPSEC) ==')
out.append('%-9s %4s %4s %4s %4s  %9s %9s %6s  %s' % ('bo do', 'TP', 'FP', 'FN', 'TN', 'precision', 'recall', 'F1', 'recall 95%CI'))
R = {}
for name, fn in DET:
    tp, fp, fn_, tn = conf(fn); p, r, f1 = prf(tp, fp, fn_); lo, hi = wilson(tp, tp + fn_); R[name] = (p, r, f1)
    out.append('%-9s %4d %4d %4d %4d  %9.2f %9.2f %6.2f  [%.2f, %.2f]' % (name, tp, fp, fn_, tn, p, r, f1, lo, hi))
out.append('== Bao nham cua bo do DUR>=5s theo lop hop le ==')
fpc = collections.Counter(c for k, c in L.items() if c not in VPN and d_dur(U[k]))
out.append('  ' + ('  '.join('%s=%d/%d' % (c, n, cnt[c]) for c, n in sorted(fpc.items())) or '(khong co)'))
out.append('== Quet nguong cho bo do DUR (thoi gian song >= T giay) ==')
out.append('%6s %9s %9s %6s' % ('T(s)', 'precision', 'recall', 'F1')); best = (0, 0)
for T in (1, 2, 3, 5, 8, 12, 16, 20, 30, 40):
    tp = fp = fn_ = 0
    for k, c in L.items():
        hit = d_dur(U[k], T)
        if c in VPN and hit: tp += 1
        elif c in VPN: fn_ += 1
        elif hit: fp += 1
    p, r, f1 = prf(tp, fp, fn_); out.append('%6d %9.2f %9.2f %6.2f' % (T, p, r, f1)); best = max(best, (f1, T))
out.append('Nguong tot nhat cua DUR: T=%ds F1=%.2f  (so voi COMBO F1=%.2f)' % (best[1], best[0], R['COMBO'][2]))
ok = all(cnt[c] >= 3 for c in VPN) and sum(1 for c in cnt if c not in VPN and cnt[c] >= 3) >= 4
if ok: out.append('BULK_PASS')
open(os.path.expanduser('~/bulk_eval.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
