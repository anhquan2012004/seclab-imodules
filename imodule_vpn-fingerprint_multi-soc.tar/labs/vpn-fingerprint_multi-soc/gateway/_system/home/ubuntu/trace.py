#!/usr/bin/env python3
import collections, csv, os, sqlite3, subprocess, sys
from scapy.all import rdpcap, Ether, IP
H = os.path.expanduser('~/'); V = H + 'verdict.csv'
if not os.path.exists(V): sys.exit('THIEU verdict.csv: chay Task 3 (python3 ~/identify.py) truoc')
pcap = os.path.expanduser(sys.argv[1]) if len(sys.argv) > 1 else H + 'pcaps/scene.pcap'
if os.path.exists(H + 'remote_logs.sh'): subprocess.run([H + 'remote_logs.sh'], capture_output=True)
def read(p):
    try: return open(p, errors='ignore').read()
    except OSError: return ''
dns = read(H + 'dns_lab.log') or read(os.environ.get('DNSLOG', '/var/log/dns_lab.log')) or subprocess.run(['sudo', 'cat', '/var/log/dns_lab.log'], capture_output=True, text=True).stdout
squid = read(H + 'remote_logs/vpn-server.log'); web = read(H + 'remote_logs/web-server.log')
viol = collections.defaultdict(lambda: {'labels': set(), 'dst': set()})
for r in csv.DictReader(open(V)):
    if r['verdict'] == 'VIOLATION': viol[r['client']]['labels'].add(r['label']); viol[r['client']]['dst'].add(r['dst'])
mac = {}
for p in rdpcap(pcap):
    if p.haslayer(IP) and p.haslayer(Ether) and p[IP].src in viol: mac.setdefault(p[IP].src, p[Ether].src)
db = sqlite3.connect(H + 'idm.db'); rows = []; lines = []
for ip, v in sorted(viol.items()):
    r = db.execute('select user, dept from devices where mac=?', (mac.get(ip, ''),)).fetchone() or ('?', '?')
    names = sorted({l.split('name=')[1].split()[0] for l in dns.splitlines() if 'client=%s ' % ip in l and 'qtype=1 ' in l and 'name=' in l})
    sq = sum(1 for l in squid.splitlines() if ip in l and 'TCP_' in l)
    vps = sum(1 for l in web.splitlines() if ' 10.0.2.10 ' in l or '10.0.2.10 - -' in l)
    rows.append([ip, r[0], mac.get(ip, '?'), '|'.join(sorted(v['labels'])), '|'.join(names) or '-', sq, 'yes' if (vps and any(l in v['labels'] for l in ('OPENVPN', 'WIREGUARD'))) else 'no'])
    lines.append('USER=%s IP=%s MAC=%s DEPT=%s KENH=%s DNS=%s SQUID_THAY_IP_THAT=%d WEB_CHI_THAY_VPS=%s' % (r[0], ip, mac.get(ip, '?'), r[1], '+'.join(sorted(v['labels'])), ','.join(names) or '-', sq, rows[-1][6]))
w = csv.writer(open(H + 'who.csv', 'w'), lineterminator='\n'); w.writerow(['ip', 'user', 'mac', 'labels', 'dns_names', 'squid_hits', 'web_saw_vps_only']); w.writerows(rows)
known = sum(1 for r in rows if r[1] != '?')
lines.append('TRACE_OK users=%d' % known if known >= 3 and any(r[4] != '-' for r in rows) else 'TRACE_INCOMPLETE users=%d' % known)
open(H + 'trace.txt', 'w').write('\n'.join(lines) + '\n'); print('\n'.join(lines))
