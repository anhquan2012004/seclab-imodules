#!/usr/bin/env python3
import json, os, pwd, re, socketserver, time
H = '/home/ubuntu/'
TRUTH = {'10.0.1.101': ('nguyen_van_a', {'OPENVPN'}, 'VIOLATION'),
         '10.0.1.102': ('tran_thi_b', {'WIREGUARD'}, 'VIOLATION'),
         '10.0.1.103': ('le_van_c', set(), 'COMPLIANT'),
         '10.0.1.104': ('pham_van_d', {'HTTP_PROXY', 'SSH'}, 'VIOLATION')}
class Hd(socketserver.StreamRequestHandler):
    def handle(self):
        try:
            data = json.loads(self.rfile.readline().decode())
        except ValueError:
            self.wfile.write(b'JSON loi\n')
            return
        by = {d.get('ip'): d for d in data}
        err = []
        for ip, (user, labels, verdict) in TRUTH.items():
            d = by.get(ip, {})
            why = []
            if d.get('user', '').strip().lower() != user:
                why.append('nguoi_dung')
            got = {x.upper() for x in re.split(r'[,\s]+', d.get('labels', '')) if x}
            if got != labels:
                why.append('kenh_tunnel')
            if d.get('verdict', '') != verdict:
                why.append('ket_luan')
            if why:
                err.append('%s: sai %s' % (ip, ', '.join(why)))
        t = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'errors': err, 'status': 'TICKET_SUBMITTED' if not err else 'TICKET_REJECTED'}
        p = H + 'forensics_ticket.json'
        open(p, 'w').write(json.dumps(t, indent=2) + '\n')
        u = pwd.getpwnam('ubuntu')
        os.chown(p, u.pw_uid, u.pw_gid)
        self.wfile.write((json.dumps(t, indent=2) + '\n').encode())
socketserver.TCPServer.allow_reuse_address = True
socketserver.TCPServer(('127.0.0.1', 5003), Hd).serve_forever()
