#!/bin/bash
H=$(hostname); D=$HOME/ev_$H; rm -rf $D $HOME/ev_$H.tar*; mkdir -p $D; cd $D
date -u > date.txt; ip -br addr > ip.txt; ip route > route.txt
sudo ss -tunap > ss.txt 2>&1; ps auxww > ps.txt
sudo wg show > wg.txt 2>&1; sudo swanctl --list-sas > ipsec.txt 2>&1; sudo ip xfrm state > xfrm.txt 2>&1
sudo cp /var/log/openvpn-client.log ovpn.log 2>/dev/null
sudo cp /var/log/syslog syslog 2>/dev/null; sudo chown $(id -u):$(id -g) * 2>/dev/null
cd $HOME; tar -cf ev_$H.tar ev_$H; sha256sum ev_$H.tar > ev_$H.tar.sha256
python3 $HOME/send.py ev_$H.tar; python3 $HOME/send.py ev_$H.tar.sha256
