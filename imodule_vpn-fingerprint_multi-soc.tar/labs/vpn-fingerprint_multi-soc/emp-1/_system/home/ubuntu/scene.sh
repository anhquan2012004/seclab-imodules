#!/bin/bash
N=${1:-3}
for i in $(seq 1 $N); do
  ~/vpn.sh up > /dev/null; curl -s -m 5 http://www.weibo.com > /dev/null; sleep 13; ~/vpn.sh down > /dev/null; sleep 1
done
echo SCENE_DONE
