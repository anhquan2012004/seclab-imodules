#!/bin/bash
[ $# -ge 2 ] || { echo "usage: load.sh GIAY URL..."; exit 1; }
T=$1; shift; E=$((SECONDS+T))
while [ $SECONDS -lt $E ]; do for u in "$@"; do curl -sk -m 3 -o /dev/null "$u"; done; sleep 4; done
echo LOAD_DONE
