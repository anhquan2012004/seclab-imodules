#!/bin/bash
N=${1:-6}
for i in $(seq 1 $N); do
  ~/vpn.sh up > /dev/null; sleep 35; ~/vpn.sh down > /dev/null; sleep 3
done
echo BULK_DONE
