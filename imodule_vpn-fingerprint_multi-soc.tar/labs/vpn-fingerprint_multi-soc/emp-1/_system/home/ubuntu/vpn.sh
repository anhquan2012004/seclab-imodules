#!/bin/bash
[ "$(id -u)" = 0 ] || exec sudo "$0" "$@"
case "$1" in
  up) pkill openvpn; pkill -f "ssh -f -N -L"; sleep 1
      if [ "$2" = nested ]; then
        ssh -f -N -L 127.0.0.1:2443:127.0.0.1:443 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i /home/ubuntu/.ssh/id_ed25519 ubuntu@10.0.2.10 || { echo SSH_FAIL; exit 1; }
        REM="127.0.0.1 2443"; W=12
      else REM="10.0.2.10 ${2:-443}"; W=8; fi
      sed -E "s/^remote 10.0.2.10 [0-9]+/remote $REM/" /etc/openvpn/client.ovpn > /tmp/client_run.ovpn
      openvpn --config /tmp/client_run.ovpn --daemon --log /var/log/openvpn-client.log; sleep $W; ip -br addr show tun0 || tail -5 /var/log/openvpn-client.log ;;
  down) pkill openvpn; pkill -f "ssh -f -N -L"; echo OVPN_DOWN ;;
  status) ip -br addr show tun0; ip route get 10.0.2.20 ;;
  *) echo "usage: vpn.sh up [cong|nested]|down|status" ;;
esac
