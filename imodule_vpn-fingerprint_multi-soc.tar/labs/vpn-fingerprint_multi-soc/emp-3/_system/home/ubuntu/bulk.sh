#!/bin/bash
N=${1:-6}
for i in $(seq 1 $N); do
  ~/vpn.sh up > /dev/null; ~/load.sh 20 https://10.0.2.30/ > /dev/null; ~/vpn.sh down > /dev/null; sleep 3
done
echo BULK_DONE
