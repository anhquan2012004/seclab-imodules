#!/bin/bash
N=${1:-3}
for i in $(seq 1 $N); do
  ~/vpn.sh up > /dev/null; ~/load.sh 12 https://10.0.2.30/ > /dev/null; ~/vpn.sh down > /dev/null; sleep 1
done
echo SCENE_DONE
