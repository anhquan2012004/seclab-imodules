#!/bin/bash
[ "$(id -u)" = 0 ] || exec sudo "$0" "$@"
case "$1" in
  up) swanctl --initiate --child corp 2>&1 | grep -E 'established|failed|error' ;;
  down) swanctl --terminate --ike corp 2>&1 | grep -E 'terminat|failed|error' ;;
  status) swanctl --list-sas 2>&1 | grep -E 'ESTABLISHED|INSTALLED|bytes' ;;
  *) echo "usage: vpn.sh up|down|status" ;;
esac
