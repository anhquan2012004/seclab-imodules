#!/bin/bash
[ $# -eq 3 ] || { echo "usage: run_filters.sh PCAP FILTERS LOGDIR"; exit 1; }
grep -q '__' "$2" && { echo "RULES_INCOMPLETE: file bo loc con cho trong __"; exit 1; }
rm -rf "$3"; mkdir -p "$3"; : > "$3/hits.log"; : > "$3/summary.txt"
while IFS='|' read -r NAME FLT; do
  [ -n "$NAME" ] || continue
  OUT=$(tshark -r "$1" -Y "$FLT" -T fields -e ip.src -e ip.dst 2>&1)
  if echo "$OUT" | grep -q '^tshark:'; then echo "RULES_INVALID: $NAME -> $(echo "$OUT" | grep '^tshark:' | head -1)"; rm -rf "$3"; exit 1; fi
  N=$(echo "$OUT" | grep -c '^[0-9]')
  echo "$OUT" | grep '^[0-9]' | sort | uniq | sed "s/^/$NAME /" >> "$3/hits.log"
  echo "$NAME hits=$N" >> "$3/summary.txt"
done < "$2"
cat "$3/summary.txt"
