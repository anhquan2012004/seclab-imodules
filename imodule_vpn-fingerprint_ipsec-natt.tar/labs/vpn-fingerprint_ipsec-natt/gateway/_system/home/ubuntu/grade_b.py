#!/usr/bin/env python3
import os
H = os.path.expanduser('~/')
G = [('QUANSAT', 'Quan sat khong NAT, co NAT, rekey, dau van tay IKE (Task 3-5)', [('nonat', 'reports/2_nonat_in.txt chua "MODE="', 'reports/2_nonat_in.txt', 'MODE='), ('nat', 'reports/3_nat_in.txt chua "MODE=ESP_IN_UDP_4500"', 'reports/3_nat_in.txt', 'MODE=ESP_IN_UDP_4500'), ('rekey', 'reports/3_nat_in.txt chua "REKEY_OBSERVED"', 'reports/3_nat_in.txt', 'REKEY_OBSERVED'), ('print', 'ike_prints.txt chua "DISTINCT_PRINTS=3"', 'ike_prints.txt', 'DISTINCT_PRINTS=3')]), ('CAMBIEN', 'Vi tri cam bien, conntrack, cam bien bat muon (Task 6, 8)', [('sensor', 'sensor_report.txt chua "VIA=CONNTRACK"', 'sensor_report.txt', 'VIA=CONNTRACK'), ('noinit', 'logs_est/summary.txt chua "IKE_SA_INIT hits=0"', 'logs_est/summary.txt', 'IKE_SA_INIT hits=0')]), ('BOLOC', 'Bo loc theo noi dung goi (Task 7)', [('ike', 'logs_nonat/hits.log chua "IKE_SA_INIT"', 'logs_nonat/hits.log', 'IKE_SA_INIT'), ('esp', 'logs_nonat/hits.log chua "ESP"', 'logs_nonat/hits.log', 'ESP'), ('natt', 'logs_nat/hits.log chua "IKE_4500_MARKER"', 'logs_nat/hits.log', 'IKE_4500_MARKER'), ('keepalive', 'logs_nat/hits.log chua "NATT_KEEPALIVE"', 'logs_nat/hits.log', 'NATT_KEEPALIVE')]), ('KETLUAN', 'Bo do theo IP dich va bien ban (Task 9-10)', [('eval', 'eval_metrics.txt chua "LAB_IPSEC_PASS"', 'eval_metrics.txt', 'LAB_IPSEC_PASS'), ('ticket', 'forensics_ticket.json chua "TICKET_SUBMITTED"', 'forensics_ticket.json', 'TICKET_SUBMITTED')])]
def has(f, s):
    p = H + f
    return os.path.exists(p) and s in open(p, errors='ignore').read()
out = []; allok = True
for tag, title, items in G:
    res = [(i, has(i[2], i[3])) for i in items]; n = sum(r for _, r in res)
    out.append('== %s: %s ==' % (tag, title))
    for i, r in res: out.append('  [%s] %-11s %s' % ('OK   ' if r else 'THIEU', i[0], i[1]))
    ok = n == len(items); allok = allok and ok
    out.append('NHOM_%s=%s %d/%d' % (tag, 'OK' if ok else 'THIEU', n, len(items)))
if allok: out.append('LAB_B_COMPLETE')
open(H + 'grade_b.txt', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
