#!/usr/bin/env python3
import collections, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcapio import packets
if len(sys.argv) < 2: sys.exit('usage: esp_infer.py PCAP')
L = collections.defaultdict(list)
for p in packets(sys.argv[1]):
    if p['proto'] == 'esp' and len(p['pay']) >= 24:
        L[(p['src'], p['dst'], 'esp')].append(len(p['pay']))
    elif p['proto'] == 'udp' and 4500 in (p['sport'], p['dport']) and len(p['pay']) > 24 and p['pay'][:4] != b'\0\0\0\0':
        L[(p['src'], p['dst'], 'udp4500')].append(len(p['pay']))
out = []
tot = ok = 0
for (s, d, m), ls in sorted(L.items()):
    n = len(ls); mean = sum(ls) / n; sd = (sum((x - mean) ** 2 for x in ls) / n) ** 0.5
    fit = sum(1 for x in ls if x % 16 == 8) / n
    tot += n; ok += sum(1 for x in ls if x % 16 == 8)
    out.append('%s -> %s [%s] goi=%d size min/tb/max=%d/%.0f/%d stdev=%.0f  (len%%16==8): %.0f%%  nguong_tren_payload_ung_dung=%dB' % (s, d, m, n, min(ls), mean, max(ls), sd, 100 * fit, max(ls) - 42))
if tot and ok / tot >= 0.95:
    out.append('ESP_BLOCK_INFERRED: %.0f%% goi co len = 8 + IV16 + ban_ma(boi 16) + ICV16 -> khoi 16 byte (kieu AES-CBC), IV 16, ICV 16, khong can khoa' % (100 * ok / tot))
open(os.path.expanduser('~/esp_infer.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
