#!/bin/bash
[ -n "$2" ] || { echo "usage: cap2.sh TEN GIAY [LOC]"; exit 1; }
mkdir -p ~/pcaps
IN=$(ip -o -4 addr show | awk '$4 ~ /^10\.0\.1\.1\//{print $2}')
OUT=$(ip -o -4 addr show | awk '$4 ~ /^10\.0\.2\.1\//{print $2}')
F=${3:-ip proto 50 or udp port 500 or udp port 4500}
echo "Bat goi $2 giay: trong($IN) -> ${1}_in.pcap ; ngoai($OUT) -> ${1}_out.pcap"
(sudo timeout -s INT $2 stdbuf -oL conntrack -E -p udp > ~/pcaps/$1_conntrack.txt 2>/dev/null) &
(sudo timeout -s INT $2 tcpdump -i $OUT -nn -U -w - "$F" > ~/pcaps/$1_out.pcap 2>/dev/null) &
sudo timeout -s INT $2 tcpdump -i $IN -nn -U -w - "$F" > ~/pcaps/$1_in.pcap 2>/dev/null
wait
sudo conntrack -L -p udp 2>/dev/null >> ~/pcaps/$1_conntrack.txt
echo "Xong: in=$(tcpdump -nn -r ~/pcaps/$1_in.pcap 2>/dev/null | wc -l) goi, out=$(tcpdump -nn -r ~/pcaps/$1_out.pcap 2>/dev/null | wc -l) goi, conntrack=$(wc -l < ~/pcaps/$1_conntrack.txt) dong"
