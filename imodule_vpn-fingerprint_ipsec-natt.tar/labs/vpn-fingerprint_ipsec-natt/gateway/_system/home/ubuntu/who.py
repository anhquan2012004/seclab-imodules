#!/usr/bin/env python3
import os, re, sqlite3, sys
from scapy.all import rdpcap, Ether, IP, UDP
if len(sys.argv) < 2: sys.exit('usage: who.py TEN_MAU  (vi du: who.py 3_nat)')
H = '/home/ubuntu/'; n = sys.argv[1]; db = sqlite3.connect(H + 'idm.db'); GW = '10.0.2.1'
ok = {l.split(',')[0].strip() for l in open(H + 'approved_vpn.csv') if l.strip() and not l.startswith('#')}
by_mac = lambda m: db.execute('select user, dept from devices where mac=?', (m,)).fetchone() or ('?', '?')
by_ip = lambda a: db.execute('select user, dept from devices where ip=?', (a,)).fetchone() or ('?', '?')
ct = []
for l in open(H + 'pcaps/%s_conntrack.txt' % n, errors='ignore') if os.path.exists(H + 'pcaps/%s_conntrack.txt' % n) else []:
    m = re.search(r'src=([\d.]+) dst=([\d.]+) sport=(\d+) dport=(\d+).*?src=([\d.]+) dst=([\d.]+) sport=(\d+) dport=(\d+)', l)
    if m: ct.append(m.groups())
def hit(ip, p): return ip.proto == 50 or (p.haslayer(UDP) and (p[UDP].dport in (500, 4500) or p[UDP].sport in (500, 4500)))
out = ['== CAM BIEN PHIA TRONG (LAN, truoc NAT) ==']; seen = set()
for p in rdpcap(H + 'pcaps/%s_in.pcap' % n):
    if p.haslayer(IP) and p.haslayer(Ether) and p[IP].src.startswith('10.0.1.') and p[IP].src != '10.0.1.1' and hit(p[IP], p):
        k = (p[IP].src, p[IP].dst, p[Ether].src)
        if k not in seen:
            seen.add(k); u, d = by_mac(p[Ether].src)
            out.append('INSIDE  src=%s mac=%s USER=%s DEPT=%s -> dst=%s APPROVED=%s ATTRIBUTION=OK' % (k[0], k[2], u, d, k[1], 'yes' if k[1] in ok else 'no'))
out.append('== CAM BIEN PHIA NGOAI (sau NAT) =='); seen = set()
for p in rdpcap(H + 'pcaps/%s_out.pcap' % n):
    if not (p.haslayer(IP) and p[IP].src == GW and hit(p[IP], p)): continue
    ip = p[IP]; sp = p[UDP].sport if p.haslayer(UDP) else 0; dp = p[UDP].dport if p.haslayer(UDP) else 0
    k = (sp, ip.dst, dp)
    if k in seen: continue
    seen.add(k); out.append('OUTSIDE src=%s:%s -> dst=%s:%s ATTRIBUTION=UNATTRIBUTABLE (chi thay IP gateway)' % (GW, sp, ip.dst, dp))
    for o in ct:
        if o[5] == GW and o[7] == str(sp) and o[4] == ip.dst and o[6] == str(dp):
            u, d = by_ip(o[0]); out.append('        + conntrack: EMP=%s USER=%s DEPT=%s VIA=CONNTRACK' % (o[0], u, d)); break
open(H + 'sensor_report.txt', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
