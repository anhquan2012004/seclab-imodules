#!/usr/bin/env python3
import collections, os, sys
from scapy.all import rdpcap, IP, UDP
EX = {34: 'IKE_SA_INIT', 35: 'IKE_AUTH', 36: 'CREATE_CHILD_SA', 37: 'INFORMATIONAL'}
if len(sys.argv) < 2: sys.exit('usage: ipsec_report.py PCAP')
f = sys.argv[1]; name = os.path.basename(f).replace('.pcap', '')
cnt = collections.Counter(); ike = []; spis = collections.defaultdict(dict); t0 = None
def esp(t, key, b):
    q = int.from_bytes(b[4:8], 'big'); e = spis[key].setdefault(b[:4].hex(), [t, 0, q, q]); e[1] += 1; e[2] = min(e[2], q); e[3] = max(e[3], q)
for p in rdpcap(f):
    if not p.haslayer(IP): continue
    ip = p[IP]; t = float(p.time); t0 = t if t0 is None else t0; t -= t0
    if ip.proto == 50: cnt['ESP_RAW'] += 1; esp(t, (ip.src, 0, ip.dst, 0), bytes(ip.payload)); continue
    if not p.haslayer(UDP): continue
    u = p[UDP]; b = bytes(u.payload); pt = 4500 if 4500 in (u.sport, u.dport) else (500 if 500 in (u.sport, u.dport) else 0)
    if pt == 4500 and b == b'\xff': cnt['NATT_KEEPALIVE'] += 1
    elif pt == 4500 and b[:4] == b'\0\0\0\0' and len(b) > 32: h = b[4:]; cnt['IKE_4500'] += 1; ike.append((t, ip.src, ip.dst, 4500, EX.get(h[18], h[18]), not h[19] & 0x20))
    elif pt == 4500 and len(b) >= 8: cnt['ESP_IN_UDP'] += 1; esp(t, (ip.src, u.sport, ip.dst, u.dport), b)
    elif pt == 500 and len(b) > 28: cnt['IKE_500'] += 1; ike.append((t, ip.src, ip.dst, 500, EX.get(b[18], b[18]), not b[19] & 0x20))
out = ['== ipsec_report: %s ==' % name]
if cnt['ESP_RAW']: out.append('MODE=ESP_RAW  (ESP giao thuc 50, khong co cong: %d goi)' % cnt['ESP_RAW'])
if cnt['ESP_IN_UDP']: out.append('MODE=ESP_IN_UDP_4500  (ESP boc trong UDP 4500: %d goi)' % cnt['ESP_IN_UDP'])
out.append('IKE tren UDP500=%d  IKE tren UDP4500=%d  NAT_KEEPALIVE(1 byte 0xFF)=%d' % (cnt['IKE_500'], cnt['IKE_4500'], cnt['NATT_KEEPALIVE']))
out.append('-- Yeu cau IKE dau tien cua moi huong --'); seen = set()
for t, s, d, pt, n, rq in ike:
    if rq and (s, d, pt, n) not in seen: seen.add((s, d, pt, n)); out.append('  t=%6.1fs %s -> %s UDP%d %s' % (t, s, d, pt, n))
out.append('-- SPI theo huong (so goi uoc tinh = seq_max - seq_min + 1) --')
for (s, sp, d, dp), m in sorted(spis.items()):
    out.append('  %s:%s -> %s:%s : %d SPI' % (s, sp or '-', d, dp or '-', len(m)))
    for spi, (t, n, lo, hi) in sorted(m.items(), key=lambda kv: kv[1][0]): out.append('      spi=0x%s thay=%d goi seq=%d..%d (uoc tinh %d goi) tu t=%.1fs' % (spi, n, lo, hi, hi - lo + 1, t))
ip_pairs = {tuple(sorted((k[0], k[2]))) for k in spis}; four = {tuple(sorted(((k[0], k[1]), (k[2], k[3])))) for k in spis}
ncc = sum(1 for x in ike if x[4] == 'CREATE_CHILD_SA' and x[5])
out.append('TUNNELS_BY_IP_PAIR=%d  TUNNELS_BY_4TUPLE=%d  CREATE_CHILD_SA_REQUESTS=%d' % (len(ip_pairs), len(four), ncc))
if ncc: out.append('REKEY_OBSERVED  (SPI doi nhung do la rekey, khong phai tunnel moi)')
os.makedirs('/home/ubuntu/reports', exist_ok=True); open('/home/ubuntu/reports/%s.txt' % name, 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
