#!/bin/bash
[ "$1" = on ] || [ "$1" = off ] || { echo "usage: nat.sh on|off"; exit 1; }
sudo iptables -t nat -F POSTROUTING
[ "$1" = on ] && sudo iptables -t nat -A POSTROUTING -s 10.0.1.0/24 -d 10.0.2.0/24 -j MASQUERADE
sudo conntrack -F > /dev/null 2>&1
echo "NAT=$1"
