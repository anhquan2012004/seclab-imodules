#!/usr/bin/env python3
import json, socket, tkinter as tk
r = tk.Tk(); r.title('SOC Console - bien ban nhan vien'); rows = []
for j, h in enumerate(('IP', 'Nguoi dung', 'Diem den VPN (cach nhau dau phay)', 'Ket luan')): tk.Label(r, text=h, font=('Arial', 10, 'bold')).grid(row=0, column=j, padx=6)
for i, ip in enumerate(('10.0.1.101', '10.0.1.102', '10.0.1.103'), 1):
    tk.Label(r, text=ip).grid(row=i, column=0); u = tk.Entry(r, width=16); u.grid(row=i, column=1); d = tk.Entry(r, width=28); d.grid(row=i, column=2)
    v = tk.StringVar(value='VIOLATION'); tk.OptionMenu(r, v, 'VIOLATION', 'COMPLIANT').grid(row=i, column=3); rows.append((ip, u, d, v))
out = tk.StringVar()
def send():
    data = [{'ip': ip, 'user': u.get().strip(), 'dests': d.get().strip(), 'verdict': v.get()} for ip, u, d, v in rows]
    try:
        s = socket.create_connection(('127.0.0.1', 5002), 5); s.sendall((json.dumps(data) + '\n').encode()); s.shutdown(socket.SHUT_WR); out.set(s.makefile().read())
    except Exception as e: out.set('LOI: %s' % e)
tk.Button(r, text='Nop bien ban', command=send).grid(row=4, column=0, columnspan=4, pady=6)
tk.Label(r, textvariable=out, justify='left', wraplength=560).grid(row=5, column=0, columnspan=4)
r.mainloop()
