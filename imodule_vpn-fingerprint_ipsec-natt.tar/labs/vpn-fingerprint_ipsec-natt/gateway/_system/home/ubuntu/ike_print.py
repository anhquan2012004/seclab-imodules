#!/usr/bin/env python3
import hashlib, sqlite3, sys
from scapy.all import rdpcap, Ether, IP, UDP
N = {1: 'ENCR', 2: 'PRF', 3: 'INTEG', 4: 'DH'}
I = {(1, 12): 'AES_CBC', (1, 20): 'AES_GCM_16', (2, 2): 'HMAC_SHA1', (2, 4): 'AES128_XCBC', (2, 5): 'HMAC_SHA2_256', (2, 6): 'HMAC_SHA2_384', (2, 7): 'HMAC_SHA2_512', (3, 2): 'HMAC_SHA1_96', (3, 12): 'HMAC_SHA2_256_128', (3, 13): 'HMAC_SHA2_384_192', (4, 2): 'MODP1024', (4, 5): 'MODP1536', (4, 14): 'MODP2048', (4, 15): 'MODP3072', (4, 16): 'MODP4096', (4, 19): 'ECP256', (4, 20): 'ECP384', (4, 31): 'CURVE25519'}
if len(sys.argv) < 2: sys.exit('usage: ike_print.py PCAP_TRONG')
def proposals(b):
    nxt = b[16]; off = 28; sa = None
    while nxt and off + 4 <= len(b):
        ln = int.from_bytes(b[off + 2:off + 4], 'big')
        if nxt == 33: sa = b[off + 4:off + ln]; break
        if ln < 4: break
        nxt = b[off]; off += ln
    out = []; o = 0
    while sa and o + 8 <= len(sa):
        more = sa[o]; pl = int.from_bytes(sa[o + 2:o + 4], 'big'); t = o + 8 + sa[o + 6]; tr = []
        for _ in range(sa[o + 7]):
            tl = int.from_bytes(sa[t + 2:t + 4], 'big'); ty = sa[t + 4]; ti = int.from_bytes(sa[t + 6:t + 8], 'big'); kl = int.from_bytes(sa[t + 10:t + 12], 'big') if tl >= 12 and sa[t + 8:t + 10] == b'\x80\x0e' else 0
            tr.append((ty, ti, kl)); t += tl
        out.append(tr); o += pl
        if more == 0: break
    return out
db = sqlite3.connect('/home/ubuntu/idm.db'); res = {}
for p in rdpcap(sys.argv[1]):
    if not (p.haslayer(IP) and p.haslayer(UDP) and p.haslayer(Ether) and p[IP].src.startswith('10.0.1.') and p[IP].src != '10.0.1.1'): continue
    b = bytes(p[UDP].payload)
    if p[UDP].dport == 4500 and b[:4] == b'\0\0\0\0': b = b[4:]
    if len(b) < 40 or b[18] != 34 or b[19] & 0x20: continue
    pr = proposals(b)
    if not pr: continue
    od = '|'.join(','.join('%d-%d-%d' % x for x in tr) for tr in pr)
    so = '|'.join(','.join('%d-%d-%d' % x for x in sorted(tr)) for tr in sorted(pr))
    txt = ' | '.join(' '.join('%s=%s%s' % (N.get(a, a), I.get((a, i), i), '-%d' % k if k else '') for a, i, k in tr) for tr in pr)
    r = db.execute('select user from devices where mac=?', (p[Ether].src,)).fetchone() or ('?',)
    res[(p[IP].src, p[IP].dst, hashlib.sha256(od.encode()).hexdigest()[:12])] = (r[0], hashlib.sha256(so.encode()).hexdigest()[:12], txt)
lines = ['IKE_PRINT src=%s dst=%s USER=%s ordered=%s sorted=%s\n    %s' % (k[0], k[1], v[0], k[2], v[1], v[2][:300]) for k, v in sorted(res.items())]
lines.append('DISTINCT_PRINTS=%d' % len({k[2] for k in res}))
open('/home/ubuntu/ike_prints.txt', 'w').write('\n'.join(lines) + '\n'); print('\n'.join(lines))
