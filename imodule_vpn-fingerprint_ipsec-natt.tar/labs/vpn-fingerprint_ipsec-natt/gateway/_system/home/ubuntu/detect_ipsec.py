#!/usr/bin/env python3
import sys
from scapy.all import rdpcap, IP, UDP
IKE_PORT_A = __
IKE_PORT_B = __
ESP_PROTO = __
def flows(path):
    d = {}
    for p in rdpcap(path):
        if not p.haslayer(IP) or not p[IP].src.startswith('10.0.1.') or p[IP].src == '10.0.1.1': continue
        ip = p[IP]
        if ip.proto == ESP_PROTO or (p.haslayer(UDP) and p[UDP].dport in (IKE_PORT_A, IKE_PORT_B)): d.setdefault(ip.src, set()).add(ip.dst)
    return d
if __name__ == '__main__':
    for f in sys.argv[1:]: print(f, {k: sorted(v) for k, v in flows(f).items()})
