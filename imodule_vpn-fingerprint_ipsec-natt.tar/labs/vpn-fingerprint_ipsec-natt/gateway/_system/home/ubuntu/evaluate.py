#!/usr/bin/env python3
import importlib.util, os, re, sys
H = '/home/ubuntu/'
if re.search(r'=\s*__\s*$', open(H + 'detect_ipsec.py').read(), re.M): print('DETECTOR_INCOMPLETE: dien not cac cho __ trong ~/detect_ipsec.py'); sys.exit(1)
sp = importlib.util.spec_from_file_location('det', H + 'detect_ipsec.py'); det = importlib.util.module_from_spec(sp); sp.loader.exec_module(det)
ok = {l.split(',')[0].strip() for l in open(H + 'approved_vpn.csv') if l.strip() and not l.startswith('#')}
a, b, c = '10.0.1.101', '10.0.1.102', '10.0.1.103'
T = [('1_baseline_in.pcap', {a: False, b: False, c: False}), ('3_nat_in.pcap', {a: True, b: False, c: True}), ('4_corp_in.pcap', {c: False}), ('5_est_nat_in.pcap', {a: True, b: False, c: True}), ('6_est_raw_in.pcap', {a: True, b: False, c: True})]
tp = fp = tn = fn = 0
for pc, truth in T:
    if not os.path.exists(H + 'pcaps/' + pc): print('MISSING ' + pc); sys.exit(1)
    fl = det.flows(H + 'pcaps/' + pc)
    for ip, bad in truth.items():
        flagged = any(d not in ok for d in fl.get(ip, ()))
        if bad and flagged: tp += 1
        elif bad: fn += 1
        elif flagged: fp += 1
        else: tn += 1
txt = 'Confusion Matrix (theo nhan vien, 5 mau):\nTP = %d  FN = %d  FP = %d  TN = %d\nAccuracy = %.1f%%\n' % (tp, fn, fp, tn, 100.0 * (tp + tn) / (tp + tn + fp + fn))
if (tp, fn, fp, tn) == (6, 0, 0, 7): txt += 'LAB_IPSEC_PASS\n'
open(H + 'eval_metrics.txt', 'w').write(txt); print(txt)
