#!/usr/bin/env python3
import struct

def _parse(d, lt):
    if lt == 1:
        if len(d) < 34 or d[12:14] != b'\x08\x00':
            return None
        o = 14
    elif lt == 113:
        if len(d) < 36 or d[14:16] != b'\x08\x00':
            return None
        o = 16
    else:
        return None
    if d[o] >> 4 != 4:
        return None
    ihl = (d[o] & 15) * 4
    tl = struct.unpack('>H', d[o + 2:o + 4])[0]
    pr = d[o + 9]
    src = '.'.join(str(x) for x in d[o + 12:o + 16])
    dst = '.'.join(str(x) for x in d[o + 16:o + 20])
    q = o + ihl
    end = min(o + tl, len(d))
    if pr == 6 and end - q >= 20:
        sp, dp, sq = struct.unpack('>HHI', d[q:q + 8])
        do = (d[q + 12] >> 4) * 4
        return {'src': src, 'dst': dst, 'proto': 'tcp', 'sport': sp, 'dport': dp, 'seq': sq, 'flags': d[q + 13], 'pay': d[q + do:end]}
    if pr == 17 and end - q >= 8:
        sp, dp = struct.unpack('>HH', d[q:q + 4])
        return {'src': src, 'dst': dst, 'proto': 'udp', 'sport': sp, 'dport': dp, 'seq': 0, 'flags': 0, 'pay': d[q + 8:end]}
    if pr == 50:
        return {'src': src, 'dst': dst, 'proto': 'esp', 'sport': 0, 'dport': 0, 'seq': 0, 'flags': 0, 'pay': d[q:end]}
    return None

def packets(path):
    f = open(path, 'rb')
    g = f.read(24)
    if len(g) < 24:
        return
    m = g[:4]
    if m in (b'\xd4\xc3\xb2\xa1', b'\x4d\x3c\xb2\xa1'):
        e = '<'
    elif m in (b'\xa1\xb2\xc3\xd4', b'\xa1\xb2\x3c\x4d'):
        e = '>'
    else:
        raise ValueError('khong phai pcap co dien: ' + path)
    nano = m in (b'\x4d\x3c\xb2\xa1', b'\xa1\xb2\x3c\x4d')
    lt = struct.unpack(e + 'I', g[20:24])[0]
    while True:
        h = f.read(16)
        if len(h) < 16:
            break
        sec, frac, incl, orig = struct.unpack(e + 'IIII', h)
        data = f.read(incl)
        if len(data) < incl:
            break
        p = _parse(data, lt)
        if p:
            p['ts'] = sec + frac / (1e9 if nano else 1e6)
            yield p
