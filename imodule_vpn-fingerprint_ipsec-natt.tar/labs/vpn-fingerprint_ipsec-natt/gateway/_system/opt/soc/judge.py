#!/usr/bin/env python3
import json, os, pwd, re, socketserver, time
H = '/home/ubuntu/'
TRUTH = {'10.0.1.101': ({'10.0.2.10'}, 'nguyen_van_a'), '10.0.1.102': (set(), 'tran_thi_b'), '10.0.1.103': ({'10.0.2.10', '10.0.2.30'}, 'le_van_c')}
class Hd(socketserver.StreamRequestHandler):
    def handle(self):
        try: data = json.loads(self.rfile.readline().decode())
        except ValueError: self.wfile.write(b'JSON loi\n'); return
        ap = {l.split(',')[0].strip() for l in open(H + 'approved_vpn.csv') if l.strip() and not l.startswith('#')}
        by = {d.get('ip'): d for d in data}; err = []
        for ip, (dests, user) in TRUTH.items():
            d = by.get(ip, {}); why = []
            if d.get('user', '').strip().lower() != user: why.append('user')
            if {x for x in re.split(r'[,\s]+', d.get('dests', '').lower()) if x and x not in ('none', '-')} != dests: why.append('diem_den')
            if d.get('verdict', '') != ('VIOLATION' if any(x not in ap for x in dests) else 'COMPLIANT'): why.append('ket_luan (doi chieu approved_vpn.csv)')
            if why: err.append('%s: sai %s' % (ip, ', '.join(why)))
        t = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'errors': err, 'status': 'TICKET_SUBMITTED' if not err else 'TICKET_REJECTED'}
        open(H + 'forensics_ticket.json', 'w').write(json.dumps(t, indent=2) + '\n'); u = pwd.getpwnam('ubuntu'); os.chown(H + 'forensics_ticket.json', u.pw_uid, u.pw_gid)
        self.wfile.write((json.dumps(t, indent=2) + '\n').encode())
socketserver.TCPServer.allow_reuse_address = True
socketserver.TCPServer(('127.0.0.1', 5002), Hd).serve_forever()
