#!/bin/bash
[ "$(id -u)" = 0 ] || exec sudo "$0" "$@"
case "$1" in
  up) swanctl --initiate --child "$2" 2>&1 | grep -E 'established|failed|error' ;;
  down) swanctl --terminate --ike "$2" 2>&1 | grep -E 'terminat|failed|error' ;;
  reset) for n in personal corp; do swanctl --terminate --ike $n > /dev/null 2>&1; done; sleep 2; echo "SA_CON_LAI=$(swanctl --list-sas 2>/dev/null | grep -c ESTABLISHED)" ;;
  status) swanctl --list-sas 2>&1 | grep -E 'ESTABLISHED|INSTALLED|bytes' ;;
  *) echo "usage: vpn.sh up|down|status [personal|corp] | reset" ;;
esac
