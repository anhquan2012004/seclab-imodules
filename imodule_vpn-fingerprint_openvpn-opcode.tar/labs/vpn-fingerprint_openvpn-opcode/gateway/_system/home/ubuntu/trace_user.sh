#!/bin/bash
# Task 8: IP -> MAC (DHCP lease) -> nguoi dung (SQLite). Ghi ket qua vao ~/forensics_report.txt
IP=${1:-10.0.1.100}
L=${LEASES:-/var/lib/misc/dnsmasq.leases}
M=$(grep "$IP" "$L" | awk '{print $2}' | head -1)
echo "$M"
[ -n "$M" ] || { echo "Khong thay lease cho $IP"; exit 1; }
sqlite3 ~/enterprise_users.db "SELECT * FROM workstations WHERE mac_address='$M';" > ~/forensics_report.txt
cat ~/forensics_report.txt
