#!/usr/bin/env python3
import collections, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcapio import packets
if len(sys.argv) < 2: sys.exit('usage: opcode_noise.py PCAP')
P = [p for p in packets(sys.argv[1]) if p['proto'] == 'udp' and p['pay']]
for p in P:
    p['c2s'] = p['src'].startswith('10.0.1.') and p['dst'].startswith('10.0.2.')
    p['s2c'] = p['src'].startswith('10.0.2.') and p['dst'].startswith('10.0.1.')
cs = [p for p in P if p['c2s']]; sc = [p for p in P if p['s2c']]
idx = collections.defaultdict(list)
for q in sc: idx[(q['dport'], q['sport'])].append(q)
n = len(cs); h = sum(1 for p in cs if p['pay'][0] == 0x38)
pairs = set()
for p in cs:
    if p['pay'][0] == 0x38:
        for q in idx.get((p['sport'], p['dport']), []):
            if q['pay'][0] == 0x40 and 0 <= q['ts'] - p['ts'] <= 1.0:
                pairs.add((p['sport'], p['dport'])); break
seq = []
for p in sorted(cs + sc, key=lambda x: x['ts']):
    k = (p['sport'], p['dport']) if p['c2s'] else (p['dport'], p['sport'])
    if k in pairs: seq.append('%s%d' % ('C' if p['c2s'] else 'S', p['pay'][0] >> 3))
out = ['UDP_client_to_server=%d  byte_dau_0x38=%d  ty_le=%.4f  ky_vong_ngau_nhien=%.4f (1/256)' % (n, h, h / n if n else 0, 1 / 256),
       'LUAT_1_BYTE: so_goi_bao=%d   LUAT_CAP_0x38_ROI_0x40: so_luong_bao=%d' % (h, len(pairs)),
       'CHUOI_OPCODE_CUA_LUONG_CO_CAP (C=client, S=server): ' + (' '.join(seq[:40]) or '(khong co)')]
if h > len(pairs): out.append('LUAT_1_BYTE_BAO_NHAM=%d' % (h - len(pairs)))
out.append('OPCODE_NOISE_DONE')
open(os.path.expanduser('~/opcode_noise.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
