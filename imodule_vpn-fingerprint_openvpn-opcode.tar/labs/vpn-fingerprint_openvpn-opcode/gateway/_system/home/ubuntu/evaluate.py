#!/usr/bin/env python3
import subprocess, os
RULE = "/home/ubuntu/vpn_opcode.rules"
POS = "/home/ubuntu/logs_vpn/vpn_stealth.pcap"
NEG = ["/home/ubuntu/logs_baseline/baseline_web.pcap", "/home/ubuntu/logs_vpn/quic_test.pcap"]

def alerts(pcap):
    d = "/tmp/eval_" + os.path.basename(pcap)
    os.makedirs(d, exist_ok=True)
    subprocess.run(["sudo", "suricata", "-r", pcap, "-S", RULE, "-l", d, "-k", "none"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        return sum(1 for l in open(d + "/fast.log") if "2026001" in l)
    except Exception:
        return 0

tp = fn = fp = tn = 0
if alerts(POS) > 0:
    tp = 1
else:
    fn = 1
for f in NEG:
    if os.path.exists(f):
        if alerts(f) > 0:
            fp += 1
        else:
            tn += 1
total = tp + fn + fp + tn
print("Confusion Matrix:")
print("TP = %d  FN = %d  FP = %d  TN = %d" % (tp, fn, fp, tn))
print("Accuracy = %.0f%%" % (100.0 * (tp + tn) / total))
if tp == 1 and fp == 0:
    print("LAB_OPCODE_EVALUATION_PASSED")
