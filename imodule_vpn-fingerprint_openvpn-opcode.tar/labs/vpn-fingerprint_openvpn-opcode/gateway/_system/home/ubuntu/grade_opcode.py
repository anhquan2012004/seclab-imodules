#!/usr/bin/env python3
import os
H = os.path.expanduser('~/')
G = [('DAUVANTAY', 'Dau van tay opcode va luat Suricata', [('opcode', 'detected_opcode.txt chua "0x38"', 'detected_opcode.txt', '0x38'), ('rule', 'vpn_opcode.rules chua "2026001"', 'vpn_opcode.rules', '2026001')]), ('KETLUAN', 'Truy vet nhan vien va danh gia', [('forensics', 'forensics_report.txt chua "nguyen_van_a"', 'forensics_report.txt', 'nguyen_van_a'), ('eval', 'eval_metrics.txt chua "LAB_OPCODE_EVALUATION_PASSED"', 'eval_metrics.txt', 'LAB_OPCODE_EVALUATION_PASSED')])]
def has(f, s):
    p = H + f
    return os.path.exists(p) and s in open(p, errors='ignore').read()
out = []; allok = True
for tag, title, items in G:
    res = [(i, has(i[2], i[3])) for i in items]; n = sum(r for _, r in res)
    out.append('== %s: %s ==' % (tag, title))
    for i, r in res: out.append('  [%s] %-11s %s' % ('OK   ' if r else 'THIEU', i[0], i[1]))
    ok = n == len(items); allok = allok and ok
    out.append('NHOM_%s=%s %d/%d' % (tag, 'OK' if ok else 'THIEU', n, len(items)))
if allok: out.append('LAB_OPCODE_COMPLETE')
open(H + 'grade_opcode.txt', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
