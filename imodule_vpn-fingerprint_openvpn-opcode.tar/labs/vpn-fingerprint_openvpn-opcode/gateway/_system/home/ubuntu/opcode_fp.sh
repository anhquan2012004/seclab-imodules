#!/bin/bash
# Task 5: giai phau OpCode trong PCAP VPN va ghi byte dau vao ~/detected_opcode.txt
P=${1:-$HOME/logs_vpn/vpn_stealth.pcap}
[ -f "$P" ] || { echo "Khong thay $P"; exit 1; }
D="-d udp.port==443,openvpn"
echo "== 3 opcode dau tien =="
tshark -r "$P" $D -T fields -e openvpn.opcode | head -3
echo "== hex cua goi dau tien =="
tshark -r "$P" $D -x -c 1
OP=$(tshark -r "$P" $D -Y "openvpn.opcode==7" -T fields -e openvpn.opcode | head -1)
[ -n "$OP" ] || { echo "Khong thay opcode 7"; exit 1; }
printf "0x%02X\n" $((OP<<3)) > ~/detected_opcode.txt
echo "== byte dau = opcode 7 dich trai 3 bit =="
cat ~/detected_opcode.txt
