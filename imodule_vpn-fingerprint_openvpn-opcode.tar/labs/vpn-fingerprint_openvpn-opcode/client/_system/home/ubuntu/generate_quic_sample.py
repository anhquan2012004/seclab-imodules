#!/usr/bin/env python3
import socket, os
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
for _ in range(5):
    s.sendto(b"\xc3\x00\x00\x00\x01" + os.urandom(20), ("10.0.2.20", 443))
print("QUIC_SENT")
