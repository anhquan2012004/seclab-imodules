#!/usr/bin/env python3
import os, random, socket, sys, time
n = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
dst = (sys.argv[2] if len(sys.argv) > 2 else '10.0.2.10', 443)
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
for i in range(n):
    s.sendto(os.urandom(random.randint(20, 100)), dst)
    if i % 100 == 99:
        time.sleep(0.05)
print('NOISE_SENT', n)
