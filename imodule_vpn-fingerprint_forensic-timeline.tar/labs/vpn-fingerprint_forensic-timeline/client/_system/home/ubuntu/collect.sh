#!/bin/bash
cd $HOME; rm -rf pack client_pack.tar*; mkdir pack
cp -r triage pack/; cp .bash_history pack/bash_history; cp .local/share/vpn_audit.log usb.img .mozilla/firefox/ptit.default/places.sqlite pack/
sudo cp /var/log/sudo.log /var/log/openvpn-client.log pack/; sudo chown ubuntu:ubuntu pack/sudo.log pack/openvpn-client.log
tar -cf client_pack.tar pack; sha256sum client_pack.tar > client_pack.tar.sha256
python3 send.py client_pack.tar; python3 send.py client_pack.tar.sha256
