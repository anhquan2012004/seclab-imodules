#!/bin/bash
D=$HOME/triage; mkdir -p $D; cd $D
date -u > 1_date.txt; ip a > 2_ip_a.txt; ip route > 3_route.txt
sudo ss -tunap > 4_ss.txt; ps auxww > 5_ps.txt; sudo lsof -i -n -P > 6_lsof.txt 2>&1
P=$(pgrep -x openvpn | head -1); echo "PID=$P" > 7_openvpn_proc.txt
[ -n "$P" ] && { tr '\0' ' ' < /proc/$P/cmdline >> 7_openvpn_proc.txt; echo >> 7_openvpn_proc.txt; }
stat $HOME/.bash_history > 8_stat_history.txt
sha256sum *.txt > SHA256SUMS; echo TRIAGE_DONE
