#!/usr/bin/env python3
import os, socket, sys
f = sys.argv[1]; s = socket.create_connection(('10.0.1.1', 9000))
s.sendall((os.path.basename(f) + '\n').encode()); s.sendall(open(f, 'rb').read()); s.close(); print('SENT', f)
