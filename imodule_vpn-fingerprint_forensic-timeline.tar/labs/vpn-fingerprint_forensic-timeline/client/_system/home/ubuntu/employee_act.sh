#!/bin/bash
A=$HOME/.local/share/vpn_audit.log; SK=187
stamp() { e=$(( $(date +%s) + SK )); echo "epoch=$e time=$(date -u -d @$e +%FT%TZ) event=$1 user=ubuntu" >> $A; }
curl -s -m 5 http://www.weibo.com > /dev/null; echo "direct access EXIT=$?"
stamp CONNECT_START
sudo openvpn --config $HOME/.cache/vpn/work.ovpn --daemon --log /var/log/openvpn-client.log
sleep 8; stamp CONNECT_OK
curl -s -m 5 http://www.weibo.com | head -1
sudo rm -f $HOME/.cache/vpn/work.ovpn
: > $HOME/.bash_history; printf '#%s\nls\n#%s\npwd\n' $(date +%s) $(date +%s) >> $HOME/.bash_history
touch -d '2 days ago' $HOME/.bash_history
echo "DONE"
