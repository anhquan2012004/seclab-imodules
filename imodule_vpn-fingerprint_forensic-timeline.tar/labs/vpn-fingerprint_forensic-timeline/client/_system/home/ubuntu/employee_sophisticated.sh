#!/bin/bash
A=$HOME/.local/share/vpn_audit2.log
mkdir -p ~/.local/share ~/.cache/vpn
sudo pkill openvpn 2>/dev/null; sleep 1
cp /opt/vpnpki/* ~/.cache/vpn/ 2>/dev/null
printf 'client\ndev tun\nproto udp\nremote 10.0.2.10 1194\nnobind\nca %s/.cache/vpn/ca.crt\ncert %s/.cache/vpn/client.crt\nkey %s/.cache/vpn/client.key\ncipher AES-256-GCM\nverb 3\n' "$HOME" "$HOME" "$HOME" > ~/.cache/vpn/work2.ovpn

T_START=$(date +%s)
REAL=$T_START; FAKE=$((REAL + 7200))
echo "epoch=$FAKE time=$(date -u -d @$FAKE +%FT%TZ) event=CONNECT_START note=THOI_GIAN_TU_KHAI_SAI" >> $A
sudo openvpn --config ~/.cache/vpn/work2.ovpn --daemon --log /var/log/openvpn-client2.log
sleep 8
curl -s -m 5 http://www.weibo.com | head -1
T_MID=$(date +%s)
echo "epoch=$REAL time=$(date -u -d @$REAL +%FT%TZ) event=CONNECT_OK_THUC_TE" >> $A

cat > /tmp/full_hist.txt << HIST
cd ~/.cache/vpn
nano work2.ovpn
sudo openvpn --config ~/.cache/vpn/work2.ovpn --daemon
curl -s http://www.weibo.com
ls -la
df -h
HIST
grep -vE "openvpn|weibo|work2|cache/vpn" /tmp/full_hist.txt > ~/.bash_history
cp /tmp/full_hist.txt ~/bash_history_full.txt
TS=$(date +%s)
printf '#%s\nls -la\n#%s\ndf -h\n' $((TS-50)) $((TS-20)) >> ~/.bash_history

sleep 60
sudo pkill openvpn
T_END=$(date +%s)
echo "$T_START $T_END" > ~/vpn_window.txt

ALIBI=$((T_MID + 20))
LINE1="$(date -u -d @$ALIBI '+%b %e %H:%M:%S') : ubuntu : TTY=pts/1 ;"
printf '%s\n    PWD=/home/ubuntu ;\n    USER=root ;\n    COMMAND=/usr/bin/apt-get update\n' "$LINE1" | sudo tee -a /var/log/sudo.log > /dev/null

shred -u -z -n 3 ~/.cache/vpn/work2.ovpn
echo CASE_C_DONE
