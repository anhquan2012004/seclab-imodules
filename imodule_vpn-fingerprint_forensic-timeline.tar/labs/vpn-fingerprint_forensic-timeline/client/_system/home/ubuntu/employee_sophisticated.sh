#!/bin/bash
A=$HOME/.local/share/vpn_audit2.log
mkdir -p ~/.local/share ~/.cache/vpn
sudo pkill openvpn 2>/dev/null; sleep 1
cp /opt/vpnpki/* ~/.cache/vpn/ 2>/dev/null
printf 'client\ndev tun\nproto udp\nremote 10.0.2.10 1194\nnobind\nca %s/.cache/vpn/ca.crt\ncert %s/.cache/vpn/client.crt\nkey %s/.cache/vpn/client.key\ncipher AES-256-GCM\nverb 3\n' "$HOME" "$HOME" "$HOME" > ~/.cache/vpn/work2.ovpn
REAL=$(date +%s); FAKE=$((REAL + 7200))
echo "epoch=$FAKE time=$(date -u -d @$FAKE +%FT%TZ) event=CONNECT_START note=THOI_GIAN_TU_KHAI_SAI" >> $A
sudo openvpn --config ~/.cache/vpn/work2.ovpn --daemon --log /var/log/openvpn-client2.log
sleep 8
curl -s -m 5 http://www.weibo.com | head -1
echo "epoch=$REAL time=$(date -u -d @$REAL +%FT%TZ) event=CONNECT_OK_THUC_TE" >> $A
sudo pkill openvpn
cp ~/.bash_history /tmp/h_orig
grep -vE "openvpn|weibo|work2|cache/vpn" /tmp/h_orig > ~/.bash_history
printf '#%s\nls -la\n#%s\ndf -h\n' $(($(date +%s)-50)) $(($(date +%s)-20)) >> ~/.bash_history
ALIBI=$((REAL - 1800))
LINE="$(date -u -d @$ALIBI '+%b %e %H:%M:%S') ubuntu : TTY=pts/1 ; PWD=/home/ubuntu ; USER=root ; COMMAND=/usr/bin/apt-get update"
echo "$LINE" | sudo tee -a /var/log/sudo.log > /dev/null
shred -u -z -n 3 ~/.cache/vpn/work2.ovpn
echo CASE_C_DONE
