#!/usr/bin/env python3
import subprocess, threading, tkinter as tk
r = tk.Tk(); r.title('Thu thap chung cu (client)'); v = tk.StringVar(value='San sang')
def run(cmd):
    def w():
        v.set('Dang chay: ' + cmd)
        o = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        v.set((o.stdout + o.stderr).strip()[-500:] or 'Xong')
    threading.Thread(target=w, daemon=True).start()
tk.Label(r, text='Thu thap chung cu so', font=('Arial', 12, 'bold')).pack(padx=20, pady=6)
tk.Button(r, text='1. Triage (thu tu bay hoi)', command=lambda: run('~/triage.sh')).pack(fill='x', padx=20, pady=3)
tk.Button(r, text='2. Dong goi + gui sang gateway', command=lambda: run('~/collect.sh')).pack(fill='x', padx=20, pady=3)
tk.Button(r, text='Xem SHA256 triage', command=lambda: run('cat ~/triage/SHA256SUMS')).pack(fill='x', padx=20, pady=3)
tk.Label(r, textvariable=v, wraplength=420, justify='left').pack(padx=20, pady=8)
r.mainloop()
