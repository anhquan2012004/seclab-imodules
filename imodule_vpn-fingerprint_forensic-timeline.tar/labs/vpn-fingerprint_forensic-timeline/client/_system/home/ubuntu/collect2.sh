#!/bin/bash
cd $HOME; rm -rf pack2 client_pack2.tar*; mkdir pack2
cp .bash_history pack2/bash_history
cp .local/share/vpn_audit2.log pack2/ 2>/dev/null
sudo cp /var/log/sudo.log /var/log/openvpn-client2.log pack2/ 2>/dev/null
sudo chown ubuntu:ubuntu pack2/sudo.log pack2/openvpn-client2.log
tar -cf client_pack2.tar pack2; sha256sum client_pack2.tar > client_pack2.tar.sha256
python3 send.py client_pack2.tar; python3 send.py client_pack2.tar.sha256
