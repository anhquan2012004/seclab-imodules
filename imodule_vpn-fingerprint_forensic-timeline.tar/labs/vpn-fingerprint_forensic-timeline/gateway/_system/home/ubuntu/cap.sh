#!/bin/bash
mkdir -p ~/pcaps; F=${2:-udp port 1194 or tcp port 80}
echo "Dang bat goi vao ~/pcaps/$1.pcap (Ctrl+C de dung)"
sudo tcpdump -i eth0 -nn -U -w - "$F" > ~/pcaps/$1.pcap
