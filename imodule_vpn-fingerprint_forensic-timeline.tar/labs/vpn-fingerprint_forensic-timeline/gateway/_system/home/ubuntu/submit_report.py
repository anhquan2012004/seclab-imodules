#!/usr/bin/env python3
import os, urllib.parse, urllib.request
K = ['skew', 'remote', 'a_ip', 'a_mac', 'a_user', 'a_verdict', 'b_user', 'b_endpoint', 'b_verdict']
d = {k: '' for k in K}
for l in open(os.path.expanduser('~/report.md')):
    if ':' in l and not l.startswith('#'):
        k, v = l.split(':', 1)
        if k.strip() in d: d[k.strip()] = v.strip()
print(urllib.request.urlopen('http://127.0.0.1:5000/ticket', urllib.parse.urlencode(d).encode()).read().decode())
