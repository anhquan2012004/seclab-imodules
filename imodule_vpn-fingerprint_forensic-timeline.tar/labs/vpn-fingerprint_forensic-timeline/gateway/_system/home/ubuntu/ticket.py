#!/usr/bin/env python3
import urllib.parse, urllib.request
F = [('skew', 'Do lech dong ho may tram (giay)'), ('remote', 'Remote VPN khoi phuc tu usb.img (ip:cong)'), ('a_ip', 'Ca A - IP'), ('a_mac', 'Ca A - MAC'), ('a_user', 'Ca A - nguoi dang dung may'), ('a_verdict', 'Ca A - VIOLATION hay COMPLIANT'), ('b_user', 'Ca B - nguoi dung'), ('b_endpoint', 'Ca B - endpoint'), ('b_verdict', 'Ca B - VIOLATION hay COMPLIANT')]
d = {k: input(t + ': ') for k, t in F}
print(urllib.request.urlopen('http://127.0.0.1:5000/ticket', urllib.parse.urlencode(d).encode()).read().decode())
