#!/usr/bin/env python3
import datetime as D, re, sqlite3, subprocess, sys
if len(sys.argv) < 2: sys.exit('usage: build_timeline.py SKEW_SECONDS')
sk = int(sys.argv[1]); H = '/home/ubuntu/'; P = H + 'evidence/pack/'; R = []
iso = lambda e: D.datetime.utcfromtimestamp(e).strftime('%Y-%m-%dT%H:%M:%SZ')
def add(e, s, c, t): R.append((int(e), iso(e), s, c, t))
def tsh(f): return subprocess.run(['tshark', '-r', H + 'pcaps/case_a.pcap', '-Y', f, '-T', 'fields', '-e', 'frame.time_epoch'], capture_output=True, text=True).stdout.split()
u = tsh('udp.port==1194'); w = tsh('tcp.port==80')
if u: add(float(u[0]), 'pcap', 'high', 'first UDP/1194 packet (OpenVPN handshake)'); add(float(u[-1]), 'pcap', 'high', 'last UDP/1194 packet')
if w: add(float(w[0]), 'pcap', 'high', 'HTTP/80 to forbidden site (blocked)')
for l in open(P + 'openvpn-client.log', errors='ignore'):
    m = re.match(r'(\w{3} \w{3} +\d+ [\d:]{8} \d{4}) (.*)', l)
    if m and re.search('Peer Connection Initiated|Initialization Sequence Completed|TLS: Initial packet', m.group(2)):
        t = D.datetime.strptime(re.sub(r' +', ' ', m.group(1)), '%a %b %d %H:%M:%S %Y').replace(tzinfo=D.timezone.utc).timestamp(); add(t, 'openvpn_log', 'high', m.group(2)[:80])
y = D.datetime.utcnow().year; st = None
for l in open(P + 'sudo.log', errors='ignore'):
    m = re.match(r'(\w{3} +\d+ [\d:]{8}) ', l)
    if m: st = D.datetime.strptime('%d %s' % (y, re.sub(r' +', ' ', m.group(1))), '%Y %b %d %H:%M:%S').replace(tzinfo=D.timezone.utc).timestamp()
    c = re.search(r'COMMAND=(.*)', l)
    if c and st: add(st, 'sudo.log', 'high', 'sudo ' + c.group(1)[:70])
for l in open(P + 'vpn_audit.log'):
    m = re.search(r'epoch=(\d+).*event=(\S+)', l)
    if m: add(int(m.group(1)) - sk, 'vpn_audit', 'medium', '%s (chuan hoa -%ds)' % (m.group(2), sk))
for t, uu in sqlite3.connect(P + 'places.sqlite').execute('select v.visit_date/1000000, p.url from moz_historyvisits v join moz_places p on p.id=v.place_id'): add(t, 'browser', 'medium', 'visit ' + uu)
ts = None
for l in open(P + 'bash_history', errors='ignore'):
    l = l.strip()
    if l.startswith('#') and l[1:].isdigit(): ts = int(l[1:])
    elif l and ts: add(ts, 'bash_history', 'low', 'cmd: ' + l[:70]); ts = None
R.sort(); f = open(H + 'timeline.csv', 'w'); f.write('time_utc,source,confidence,event\n')
for r in R: f.write('%s,%s,%s,"%s"\n' % (r[1], r[2], r[3], r[4].replace('"', "'")))
f.close(); print(open(H + 'timeline.csv').read())
