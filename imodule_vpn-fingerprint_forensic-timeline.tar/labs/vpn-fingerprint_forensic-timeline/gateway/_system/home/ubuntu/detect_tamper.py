#!/usr/bin/env python3
import os, re
H = os.path.expanduser('~/evidence/pack2/'); out = []
ev = {}
for l in open(H + 'vpn_audit2.log'):
    m = re.search(r'epoch=(\d+).*event=(\S+)', l)
    if m: ev[m.group(2)] = int(m.group(1))
if 'CONNECT_START' in ev and 'CONNECT_OK_THUC_TE' in ev and ev['CONNECT_START'] > ev['CONNECT_OK_THUC_TE']:
    out.append('LOG_ORDER_VIOLATION: CONNECT_START epoch=%d xay ra SAU CONNECT_OK epoch=%d -> log tu khai da bi sua, khong dang tin' % (ev['CONNECT_START'], ev['CONNECT_OK_THUC_TE']))
hist = [l for l in open(H + 'bash_history') if not l.startswith('#')]
sudo_cmds = len(re.findall(r'COMMAND=', open(H + 'sudo.log').read()))
out.append('bash_history con %d lenh | sudo.log co %d lenh COMMAND= -> so sanh de tim lenh bi xoa chon loc' % (len(hist), sudo_cmds))
out.append('File cau hinh VPN KHONG con trong goi chung cu (da bi xoa an toan) -> phai dua vao PCAP (vpn_fp.sh) va log server (server_view.sh) de xac dinh remote endpoint')
open(os.path.expanduser('~/tamper_report.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
