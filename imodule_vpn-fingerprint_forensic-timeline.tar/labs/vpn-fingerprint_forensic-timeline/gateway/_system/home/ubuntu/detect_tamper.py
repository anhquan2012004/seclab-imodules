#!/usr/bin/env python3
import os, re
H = os.path.expanduser('~/evidence/pack2/'); out = []
ev = {}
for l in open(H + 'vpn_audit2.log'):
    m = re.search(r'epoch=(\d+).*event=(\S+)', l)
    if m: ev[m.group(2)] = int(m.group(1))
if 'CONNECT_START' in ev and 'CONNECT_OK_THUC_TE' in ev and ev['CONNECT_START'] > ev['CONNECT_OK_THUC_TE']:
    out.append('LOG_ORDER_VIOLATION: CONNECT_START epoch=%d xay ra SAU CONNECT_OK epoch=%d -> log tu khai da bi sua, khong dang tin' % (ev['CONNECT_START'], ev['CONNECT_OK_THUC_TE']))

full = [l.rstrip('\n') for l in open(H + 'bash_history_full.txt')] if os.path.exists(H + 'bash_history_full.txt') else []
kept = [l.rstrip('\n') for l in open(H + 'bash_history') if not l.startswith('#')]
removed = [l for l in full if l not in kept and l]
out.append('bash_history day du co %d lenh, sau khi "don dep" chi con %d lenh -> %d lenh bi xoa chon loc: %s' % (len(full), len(kept), len(removed), ', '.join(removed[:5]) or '(khong co)'))

win = None
if os.path.exists(H + 'vpn_window.txt'):
    a, b = open(H + 'vpn_window.txt').read().split(); win = (int(a), int(b))
    out.append('Khung gio tunnel hoat dong (tu PCAP/vpn_window.txt): %d .. %d' % win)
susp = []
import datetime as D
y = D.datetime.utcnow().year; st = None
for l in open(H + 'sudo.log'):
    m = re.match(r'(\w{3} +\d+ [\d:]{8}) ', l)
    if m: st = D.datetime.strptime('%d %s' % (y, re.sub(r' +', ' ', m.group(1))), '%Y %b %d %H:%M:%S').replace(tzinfo=D.timezone.utc).timestamp()
    c = re.search(r'COMMAND=(.*)', l)
    if c and st and win is not None and win[0] <= st <= win[1] and 'openvpn' not in c.group(1) and 'rm' not in c.group(1):
        susp.append((int(st), c.group(1)[:60]))
if susp:
    out.append('ALIBI_CONTRADICTION: %d lenh "vo hai" trong sudo.log co dau thoi gian NAM TRONG luc tunnel dang hoat dong -> mau thuan voi PCAP:' % len(susp))
    for t, c in susp: out.append('    COMMAND=%s luc epoch=%d' % (c, t))
out.append('File cau hinh VPN da bi xoa an toan (shred), khong con trong goi chung cu -> phai dua vao PCAP (vpn_fp.sh) va log server (server_view.sh) de xac dinh remote endpoint')
open(os.path.expanduser('~/tamper_report.txt'), 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
