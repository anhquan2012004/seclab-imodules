#!/usr/bin/env python3
import os, socket
os.makedirs('/home/ubuntu/evidence', exist_ok=True)
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(('0.0.0.0', 9000)); s.listen(2)
print('Dang cho 2 file tu client (cong 9000)...')
for _ in range(2):
    c, a = s.accept(); f = c.makefile('rb'); name = os.path.basename(f.readline().decode().strip())
    open('/home/ubuntu/evidence/' + name, 'wb').write(f.read()); print('RECEIVED', name, 'from', a[0])
