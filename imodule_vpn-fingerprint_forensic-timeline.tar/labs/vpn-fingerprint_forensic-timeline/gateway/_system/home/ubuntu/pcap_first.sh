#!/bin/bash
tshark -r ${1:-$HOME/pcaps/case_a.pcap} -Y "udp.port==1194" -T fields -e frame.time_epoch 2>/dev/null | head -1 | cut -d. -f1
