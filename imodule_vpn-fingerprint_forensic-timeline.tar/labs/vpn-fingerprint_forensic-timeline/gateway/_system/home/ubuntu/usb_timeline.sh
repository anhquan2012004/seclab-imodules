#!/bin/bash
cd ~/evidence/pack || { echo "Chua co ~/evidence/pack (lam Task 3 truoc)"; exit 1; }
fls -r -m / usb.img > ~/usb_body.txt
mactime -b ~/usb_body.txt -d | tee ~/usb_timeline.txt
