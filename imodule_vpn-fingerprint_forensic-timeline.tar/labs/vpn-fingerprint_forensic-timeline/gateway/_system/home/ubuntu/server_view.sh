#!/bin/bash
F=~/evidence/server_openvpn.log
[ -f $F ] || { echo "Chua co $F (chay recv_srv.py roi gui tu vpn-server)"; exit 1; }
grep -E "VERIFY OK|Peer Connection|MULTI: Learn|TLS: Initial packet" $F | tee ~/server_view.txt
