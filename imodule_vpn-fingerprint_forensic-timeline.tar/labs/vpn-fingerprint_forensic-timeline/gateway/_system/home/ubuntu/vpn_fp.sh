#!/bin/bash
P=${1:-$HOME/pcaps/case_a.pcap}
tshark -r $P -d udp.port==1194,openvpn -T fields -e openvpn.opcode 2>/dev/null | sort | uniq -c
OP=$(tshark -r $P -d udp.port==1194,openvpn -Y "openvpn.opcode==7" -T fields -e openvpn.opcode 2>/dev/null | head -1)
[ -n "$OP" ] && printf "FIRST_BYTE=0x%02X (opcode 7 = P_CONTROL_HARD_RESET_CLIENT_V2)\n" $((OP<<3)) | tee ~/vpn_fp.txt || echo "Khong thay opcode 7"
