# Bien ban dieu tra (dien sau dau hai cham, moi gia tri tren mot dong)
skew:
remote:
a_ip:
a_mac:
a_user:
a_verdict:
b_user:
b_endpoint:
b_verdict:
