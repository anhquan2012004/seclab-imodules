#!/bin/bash
sqlite3 -header -column ~/idm.db "select * from devices; select datetime(ts,'unixepoch') t, mac, user, action from login_audit order by ts; select * from vpn_tickets;"
