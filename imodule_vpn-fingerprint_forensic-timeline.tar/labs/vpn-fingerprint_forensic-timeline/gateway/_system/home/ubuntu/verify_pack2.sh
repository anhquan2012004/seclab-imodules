#!/bin/bash
cd ~/evidence || exit 1
S=$(cut -d' ' -f1 client_pack2.tar.sha256); R=$(sha256sum client_pack2.tar | cut -d' ' -f1)
[ "$S" = "$R" ] && M=MATCH || M=MISMATCH
echo "client_pack2.tar,$S,$R,$M,$(date -u +%FT%TZ)" >> chain_of_custody.csv
tail -1 chain_of_custody.csv
tar -xf client_pack2.tar; echo "Da giai nen vao ~/evidence/pack2"
