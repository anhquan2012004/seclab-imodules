#!/bin/bash
sqlite3 "${1:-$HOME/evidence/pack/places.sqlite}" "select datetime(v.visit_date/1000000,'unixepoch'), p.url from moz_historyvisits v join moz_places p on p.id=v.place_id order by v.visit_date" | tee ~/places_utc.txt
