#!/usr/bin/env python3
import os
H = os.path.expanduser('~/')
G = [('BANGCHUNG', 'Thu thap va khoi phuc chung cu', [('triage', 'evidence/chain_of_custody.csv chua "RESULT=MATCH"', 'evidence/chain_of_custody.csv', 'RESULT=MATCH'), ('recover', 'recovered_remote.txt chua "10.0.2.10"', 'recovered_remote.txt', '10.0.2.10'), ('body', 'usb_timeline.txt chua "client.ovpn"', 'usb_timeline.txt', 'client.ovpn'), ('carve', 'carve_remote.txt chua "10.0.2.10"', 'carve_remote.txt', '10.0.2.10')]), ('DONGTHOIGIAN', 'Dong thoi gian va bao ve du lieu ca nhan', [('places', 'places_utc.txt chua "weibo"', 'places_utc.txt', 'weibo'), ('timeline', 'timeline.csv chua "vpn_audit"', 'timeline.csv', 'vpn_audit'), ('redact', 'report_places.txt chua "REDACTED"', 'report_places.txt', 'REDACTED')]), ('DAUVANTAY', 'Dau van tay OpenVPN va doi chieu may chu', [('fp', 'vpn_fp.txt chua "FIRST_BYTE=0x38"', 'vpn_fp.txt', 'FIRST_BYTE=0x38'), ('srv', 'server_view.txt chua "VERIFY OK"', 'server_view.txt', 'VERIFY OK')]), ('CHONGMAO', 'Chong dieu tra va bien ban', [('tamper', 'tamper_report.txt chua "LOG_ORDER_VIOLATION"', 'tamper_report.txt', 'LOG_ORDER_VIOLATION'), ('ticket', 'forensics_ticket.json chua "TICKET_SUBMITTED"', 'forensics_ticket.json', 'TICKET_SUBMITTED')])]
def has(f, s):
    p = H + f
    return os.path.exists(p) and s in open(p, errors='ignore').read()
out = []; allok = True
for tag, title, items in G:
    res = [(i, has(i[2], i[3])) for i in items]; n = sum(r for _, r in res)
    out.append('== %s: %s ==' % (tag, title))
    for i, r in res: out.append('  [%s] %-11s %s' % ('OK   ' if r else 'THIEU', i[0], i[1]))
    ok = n == len(items); allok = allok and ok
    out.append('NHOM_%s=%s %d/%d' % (tag, 'OK' if ok else 'THIEU', n, len(items)))
if allok: out.append('LAB_D_COMPLETE')
open(H + 'grade_d.txt', 'w').write('\n'.join(out) + '\n'); print('\n'.join(out))
