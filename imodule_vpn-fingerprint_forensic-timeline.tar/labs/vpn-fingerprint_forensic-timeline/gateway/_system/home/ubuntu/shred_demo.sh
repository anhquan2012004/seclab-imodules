#!/bin/bash
# So sanh "xoa thuong" (rm) va "ghi de" (nhu shred) tren anh ext2, khong can mount.
D=$(mktemp -d); trap 'rm -rf $D' EXIT
mkdir $D/r; printf 'client\ndev tun\nproto udp\nremote 10.0.2.10 1194\n' > $D/r/xoa_thuong.ovpn; cp $D/r/xoa_thuong.ovpn $D/r/ghi_de.ovpn
truncate -s 4M $D/u.img; mke2fs -q -F -t ext2 -d $D/r $D/u.img || { echo "THIEU mke2fs"; exit 1; }
BS=$(dumpe2fs -h $D/u.img 2>/dev/null | awk '/Block size/{print $3}')
I1=$(debugfs -R "stat xoa_thuong.ovpn" $D/u.img 2>/dev/null | awk '/Inode:/{print $2}'); I2=$(debugfs -R "stat ghi_de.ovpn" $D/u.img 2>/dev/null | awk '/Inode:/{print $2}')
B2=$(debugfs -R "blocks ghi_de.ovpn" $D/u.img 2>/dev/null | tr -d ' \n')
debugfs -w -R "rm xoa_thuong.ovpn" $D/u.img > /dev/null 2>&1; debugfs -w -R "rm ghi_de.ovpn" $D/u.img > /dev/null 2>&1
dd if=/dev/urandom of=$D/u.img bs=$BS seek=$B2 count=1 conv=notrunc 2>/dev/null
R1=$(debugfs -R "cat <$I1>" $D/u.img 2>/dev/null | grep -c "remote 10.0.2.10"); R2=$(debugfs -R "cat <$I2>" $D/u.img 2>/dev/null | grep -c "remote 10.0.2.10")
echo "Khoi_ext2=${BS}B  inode_xoa_thuong=$I1  inode_ghi_de=$I2"
echo "XOA_THUONG (rm): khoi phuc duoc dong remote = $R1"
echo "GHI_DE (rm + ghi de khoi du lieu): khoi phuc duoc dong remote = $R2"
[ "$R1" = 1 ] && [ "$R2" = 0 ] && echo "SHRED_DEMO_OK: rm chi go ten, du lieu con; ghi de moi lam mat noi dung" | tee ~/shred_demo.txt
