#!/usr/bin/env python3
import os, socket
os.makedirs('/home/ubuntu/evidence', exist_ok=True)
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(('0.0.0.0', 9001)); s.listen(1)
print('Dang cho log tu vpn-server (cong 9001)...')
c, a = s.accept(); open('/home/ubuntu/evidence/server_openvpn.log', 'wb').write(c.makefile('rb').read()); print('RECEIVED server log from', a[0])
