#!/bin/bash
cd ~/evidence || exit 1
S=$(cut -d' ' -f1 client_pack.tar.sha256); R=$(sha256sum client_pack.tar | cut -d' ' -f1)
[ "$S" = "$R" ] && M=MATCH || M=MISMATCH
echo "item,sha256_client,sha256_gateway,result,verified_at_utc" > chain_of_custody.csv
echo "client_pack.tar,$S,$R,$M,$(date -u +%FT%TZ)" >> chain_of_custody.csv
cat chain_of_custody.csv; tar -xf client_pack.tar; echo "Da giai nen vao ~/evidence/pack"
