#!/bin/bash
rm -rf ~/recovered_tsk; mkdir -p ~/recovered_tsk
tsk_recover -e ~/evidence/pack/usb.img ~/recovered_tsk
find ~/recovered_tsk -type f
grep -r "^remote" ~/recovered_tsk | tee ~/carve_remote.txt
