#!/usr/bin/env python3
import json, time, urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
H = '/home/ubuntu/'
class S(BaseHTTPRequestHandler):
    def reply(self, t):
        self.send_response(200); self.send_header('Content-type', 'text/plain; charset=utf-8'); self.end_headers(); self.wfile.write(t.encode())
    def do_GET(self): self.reply('PTIT SOC ticket service\n')
    def do_POST(self):
        q = urllib.parse.parse_qs(self.rfile.read(int(self.headers.get('Content-Length', 0))).decode())
        g = lambda k: q.get(k, [''])[0].strip().lower()
        e = []
        try: ok = 182 <= int(g('skew')) <= 192
        except ValueError: ok = False
        if not ok: e.append('skew: sai')
        if '10.0.2.10' not in g('remote') or '1194' not in g('remote'): e.append('remote: sai')
        for k, v in (('a_ip', '10.0.1.100'), ('a_mac', '02:42:0a:00:01:64'), ('a_user', 'le_van_c'), ('a_verdict', 'violation'), ('b_user', 'tran_thi_b'), ('b_endpoint', '10.0.2.20'), ('b_verdict', 'compliant')):
            if g(k) != v: e.append(k + ': sai')
        try: src = {l.split(',')[1] for l in open(H + 'timeline.csv').read().splitlines()[1:]}
        except OSError: src = set()
        if len(src) < 5: e.append('timeline.csv: can it nhat 5 nguon (hien co %d)' % len(src))
        try: r = open(H + 'report_places.txt').read().lower()
        except OSError: r = ''
        if 'redacted' not in r or 'vietcombank' in r or 'benhvien' in r: e.append('report_places.txt: chua che du lieu ca nhan khong lien quan')
        if 'weibo' not in r: e.append('report_places.txt: mat bang chung weibo')
        t = {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'errors': e, 'status': 'TICKET_SUBMITTED' if not e else 'TICKET_REJECTED'}
        open(H + 'forensics_ticket.json', 'w').write(json.dumps(t, indent=2) + '\n'); self.reply(json.dumps(t, indent=2) + '\n')
HTTPServer(('0.0.0.0', 5000), S).serve_forever()
